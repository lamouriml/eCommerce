<?php 

include"storescripts/connect_to_mysql.php";
include"storescripts/session_func.php";
// pour la deconnexion
if(isset($_GET['dec'])){
	session_unset();
	session_destroy();
	}

$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// pour la fonctionalite de recherche Pricipale :
$output="";
$resCount="";
$tableAtt="";
$NonRes="";
if( isset( $_POST['rech_txt'] ) ){
	$mots=$_POST['rech_txt'];
	if($mots=="" or $mots==" " or $mots=="  "){
			$output.="SVP entrer un mots pour rechercher ";
		}		
	else{
			$sql=mysql_query("SELECT * FROM products WHERE product_name LIKE '%$mots%' ");
			$resCount=mysql_num_rows($sql);
			if($resCount==0){
			$NonRes="Aucun Resultat de la mot: <strong>$mots</strong> ";
			}
			else{
			$NonRes="Le nombre d'�lement trouver pour la mot (&nbsp;<strong>$mots</strong>&nbsp;)  est :&nbsp; <strong>$resCount</strong> �lement";
			
		while($row=mysql_fetch_array($sql) ){
	   	    
			$id=$row['id'];
			$product_name=$row['product_name'];
			$price=$row['price'];			
			$tableAtt="<table width='90%' border='1' cellspacing='3' cellpadding='3' bgcolor='#B1D8D8'  >
 				 <tr bgcolor='#99CCFF'>
    				<td width='65%'><strong>Nom de article</strong></td>
    				<td width='31%'><strong>Prix</strong></td>
    				<td width='35%' ><strong>Detaille</strong></td>
  				</tr>";
			$output.="<tr> <td> $product_name </td> <td> $price&nbsp;&nbsp;DA </td>  <td align='center'> <a href='product.php?id_get=$id'> <img src='images/simple_btn/search.png' width='24' height='24' /> </a> </td> </tr>";
		}
		$output.="</table>";
	}
	}
}

///  POUR LA RECHERCHE AVANCER ( POUR PRIX )
/*
$output_prix=" Aucun Resultat";
$resCount_prix="";
$tableAtt_prix="";
$NonRes_prix="";
if( isset( $_POST['prix1']) and isset( $_POST['prix2']) ){
	$prix1=$_POST['prix1'];
	$prix2=$_POST['prix2'];
	if($prix1=="" or $prix1=="Rechercher" or $prix2=="" or $prix2==" "){
			$output_prix.="SVP entrer les prix pour rechercher ";
		}		
	else{
			$sql_prix=mysql_query("SELECT * FROM products WHERE price between '$prix1' and '$prix2' ");
			$resCount_prix=mysql_num_rows($sql_prix);
			$NonRes_prix="Le nombre d'�lemente trouver est :&nbsp; $resCount_prix �lement <br /> les prix entre <font color='#105890' >$prix1 DA</font>  et <font color='#105890' >$prix2 DA</font> ";
		
		while($row_prix=mysql_fetch_array($sql_prix) ){
	   	    $id_prix=$row_prix['id'];
			$product_name_prix=$row_prix['product_name'];
			$price_prix=$row_prix['price'];			
			$tableAtt_prix="<table width='100%' border='1' cellspacing='3' cellpadding='3' bgcolor='#ADADAD'  >
 				 <tr bgcolor='#666666'>
    				<td width='32%'><strong>Prix</strong></td>
    				<td width='60%'><strong>Nom de l'article</strong></td>
    				<td width='35%' ><strong>Detaille</strong></td>
  				</tr>";
			$output_prix.="<tr> <td>&nbsp; $price_prix &nbsp;&nbsp;DA </td> <td> $product_name_prix </td>  <td align='center'> <a href='product.php?id_get=$id_prix'> <img src='images/simple_btn/search.png' width='30' height='27' /> </a> </td> </tr>";
		}
		$output_prix.="</table>";
	}
}
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Aide et Presentation de site</title>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>

</head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header.php");?>

<div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
           <?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>   
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
         <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  
     </form>
    </div>
  
   			<table width="100%" border="0" cellspacing="0" cellpadding="0">
   			  <tr height="100%">
   			    <td width="20%"><?php  include_once("template_menu_left.php");?></td>
   			    <td width="60%" align="center" >
            <h2> La Recherche</h2>   
     <!--<font >NB: prix 1 doit inferieure a prix 2<br/>
           prix 1 &lt; prix 2 </font><br /><br />
        	    Entre&nbsp;
  <input name="prix1" type="text" size="20" style="background:#9CF" value="Prix 1 ..." onfocus="this.value=(this.value=='Prix 1 ...')? '' : this.value ;" />
  &nbsp;Et&nbsp;&nbsp;
  <input name="prix2" type="text" size="20"  style="background:#9CF" value="Prix 2 ..." onfocus="this.value=(this.value=='Prix 2 ...')? '' : this.value ;"/>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
  <br />
  <input name="rech_prix" type="submit" value="Recherche" /><br /><br />-->
		<?php echo $NonRes.'<br />'.$tableAtt.'<br />'.$output ?>
		
		 <?php
		 //echo $NonRes_prix  $tableAtt_prix 	$output_prix 
		 ?>
                
                </td>
   			    <td width="20%"><?php  include_once("template_menu_right.php");?></td>
		      </tr>
	  </table>
  

<br/><br/><br/><br/><br/><br/><br/>


</div></div>

<?php  include_once("template_footer.php");?>
</div>
</body>
</html>
