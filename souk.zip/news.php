<?php 	
include"storescripts/session_func.php";
// pour la deconnexion
if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
	  session_destroy();
	 /* header("location:../index.php"); */
}
?>

<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// Pour selectioner les 6 dernier news 
include"storescripts/connect_to_mysql.php";
 $outputList="";
$sql=mysql_query("select * from news ORDER BY idNews DESC LIMIT 4");

/////////////////////////////////////////////////////////////////////////////////
$sql = mysql_query("SELECT * FROM news");


$newsCount = mysql_num_rows($sql); 
if (isset($_GET['pn'])) { 
    $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); 
} else {     $pn = 1;
} 
$itemsPerPage = 3; 
$lastPage = ceil($newsCount / $itemsPerPage);
if ($pn < 1) { 
    $pn = 1; 
} else if ($pn > $lastPage) { 
    $pn = $lastPage; 
} 

$centerPages = "";
$sub1 = $pn - 1;
$sub2 = $pn - 2;
$add1 = $pn + 1;
$add2 = $pn + 2;
if ($pn == 1) {
    $centerPages .=  $pn . ' &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
} else if ($pn == $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .=  $pn . ' &nbsp;';
} else if ($pn > 2 && $pn < ($lastPage - 1)) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .=  $pn . ' &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
} else if ($pn > 1 && $pn < $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= $pn ;
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
}
$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 

$sql2 = mysql_query("SELECT * FROM news $limit"); 

$paginationDisplay = ""; 
if ($lastPage != "1"){
    //$paginationDisplay .= 'Page <strong>' . $pn . '</strong> sur ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
    if ($pn != 1) {
        $previous = $pn - 1;
        $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> << </a> ';
    } 
    $paginationDisplay .=  $centerPages;
    if ($pn != $lastPage) {
        $nextPage = $pn + 1;
        $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"> >> </a> ';
    } 
}


/////////////////////////////////////////////////////////////////////////////////
if($newsCount>0){
   while($row=mysql_fetch_array($sql2)){
      $idNews=$row["idNews"];
	  $titre=$row["titre"];
	  $resume=$row["resume"];
	  $tout=$row["tout"];
	  $dateAjoute=strftime("%d %b %Y",strtotime($row["dateAjoute"]));
	  $outputList.='
	  <table width="590" border="0" cellspacing="10" cellpadding="10">
          <tr>
            <td width="20%" height="140"><img src="news_images/'.$idNews.'.jpg" alt="'.$titre.'" width="160" height="100" border="2" />		&nbsp;	</td>
            <td width="100" valign="top"><font color="orange" size=4>'.$titre.'</font><br/> '.$resume.'...<a href="newsPlus.php?idNews='.$idNews.'">&nbsp;&nbsp;Plus ++ </a>              <br/><em><font size=2>Ajouter en :&nbsp;'.$dateAjoute.'</font></em></td>
          </tr>
        </table><hr style="margin-right:15px;" color="#0099CC" />';
   }
}
else{
$outputList="news Empty!!";
}
mysql_close();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>le Journale</title>

<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header.php");?>
  <div id="pageContent" >
<div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
<input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />       </form>
     </div>  

    <div id="pubDiv" align="centre">Ajouter Votre Propre Publication </div>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr valign="top">
        <td width="20%" ><?php  include_once("template_menu_left.php");?>
        <td width="78%">
          <br/>
          <br/><font color="#006699" size="5"><strong> &nbsp;&nbsp;Les Journales : </strong></font><br/><br/>
          <div id="pagination_div">
			<?php 
		  $info_pagi='&nbsp;&nbsp;&nbsp;&nbsp;'. $paginationDisplay.'&nbsp;&nbsp;|&nbsp;<font size=2> Page  '. $pn .'  sur  '. $lastPage. '&nbsp;  |&nbsp;  Tous les Items:   ' . $newsCount; 
		  
		  echo $info_pagi;
		  ?>
          
          </div>
        
          <div id="one_prod" style="margin-right:0px;margin-left:0px;  ">
		  <?php echo $outputList; ?>
          </div>
          <div id=pagination_div>
		  <?php echo $info_pagi;?>
          </font></div></td>
        <td width="20%"><?php  include_once("template_menu_right.php");?></td>
      </tr>
    </table>
	
   <BR /><BR /><br /><br /><br /><br /><br /><br /><br /><br />
  </div></div>
  <?php  include_once("template_footer.php");?>
</div>
</body>
</html>
