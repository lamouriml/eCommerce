<?php 
	include"storescripts/connect_to_mysql.php"; 
	include"storescripts/session_func.php";



$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// laison avec le session de la logine admin
$suppComm="";

if(!isset($_SESSION["session"])){
header("commente.php");
}
else{
include"storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' and estAdmin='yes' LIMIT 1");
}
$existCount=mysql_num_rows($sql);
?>

<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 


$contact_div="";
if(isset($_GET['id_com_get'])){
	$targetID=$_GET['id_com_get'];
    $id2=$_GET['id_com_get'];

//	 Ajouter Commentaire
		$time_ = date("H:i:s"); 
		$date_ = date("Y/m/d");
		if(isset($_POST['com_title']) ){
			$com_text=mysql_real_escape_string($_POST['com_text']);
			$com_title=mysql_real_escape_string($_POST['com_title']);
			$com_by=mysql_real_escape_string($_POST['com_by']);
			mysql_query("INSERT INTO comment_a(com_id_a,com_by,com_text,com_title,com_time,com_date,id_a) VALUES ('','$com_by','$com_text','$com_title','$time_','$date_','".$id2."' )") or die(	mysql_error());	
  		}

// Afficher Commentaire 
			$liste_comm='';		
			$sql1=mysql_query("select * from comment_a WHERE id_a='".$id2."'  order by com_id_a desc" ) or die(mysql_error());
			$CommCount=mysql_num_rows($sql1);
			if($CommCount>0){
   				while($row1=mysql_fetch_array($sql1)){
	  				$com_id_aff=$row1["com_id_a"];
						// pour Afficher la boutton Supprimer dans la cas de l'Administrateure
						if($existCount==0){	header("commente.php");}
						else{$suppComm="<a href='commente.php?id_supp_comm=$com_id_aff&id_com_get=$id2'>Supprimer</a>";}
					
					$com_text_aff=$row1["com_text"];
	   				$com_title_aff=$row1["com_title"];
					$com_by_aff=$row1["com_by"];
					$com_date=$row1["com_date"];
					$com_time=$row1["com_time"];					
					$liste_comm.="<font size='3'>&nbsp; By&nbsp;<strong><ins>$com_by_aff :</ins></strong></font> &nbsp;<strong>$com_title_aff </strong>&nbsp;&nbsp;$suppComm&nbsp;
         <br/>&nbsp;&nbsp;-  $com_text_aff<br/>
		 <font size='1'>
		 <em>$com_date&nbsp;|&nbsp; $com_time</em></font>
         <hr style='margin-right: 10px; border:solid 1px #006699;' / >";
   				}
			}
			else{
			       $liste_comm='Pas de commentaire !!<br/><br/>';	
				}
				

}
if(isset($_GET['id_supp_comm']) && isset($_GET['id_com_get'])){
$id_to_delete=$_GET['id_supp_comm'];
$idcom=$_GET['id_com_get'];
mysql_query("DELETE FROM comment_a WHERE com_id_a='$id_to_delete'") or die(mysql_error) ;
header("location:commente.php?id_com_get=$idcom");
}



?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Ajoute une commentaire </title>

<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>


</head>

<body>

<div align="center" id="mainWrapper">
<?php  include_once("template_header.php");?>
  <div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
     <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  </form>
     </div>  
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      
      </tr>
      <tr valign="top">
        <td width="23%" height="248">
        <?php include_once("template_menu_left.php"); ?>
        </td>
       
        <td width="77%"> <BR/><BR/>
          <h2 align="center"  ><font color="#006699" size="+2" >Ajouter Votre Commentaire</font></h2><a href="product.php?id_get=<?php echo $id2 ?>"><h3 align="center">Reteur</h3></a>
          <table width="100%" height="400" border="0" cellpadding="10" cellspacing="5" align="left">
            <tr>
              <td width="100%" height="174" colspan="2" align="left">              
                
                      
      <div id="one_prod" >
      <?php echo $liste_comm ?>
       </div >
            <br />
                <br />
              <legend></legend>
              <form id="form1" name="form1" method="post" action="commente.php?id_com_get=<?php echo $id2 ?>">
            <table width="400" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><strong>Nom :</strong></td>
              </tr>
              <tr>
                <td width="575">
                  <input name="com_by" type="text" class="iscritfield" id="textfield" size="30" /></td>
              </tr>
              <tr>
                <td><strong>Titre :</strong></td>
              </tr>
              <tr>
                <td><input name="com_title" type="text" class="iscritfield" id="textfield2" size="45" /></td>
              </tr>
              <tr>
                <td><strong>Commentaire:</strong></td>
              </tr>
              <tr>
                <td><textarea name="com_text" cols="40" rows="5" class="iscritfield"> Votre Comentaire ...</textarea>
                  <br/>
                  <input name="thisID" type="hidden" value="<?php echo $id ?>" />	
                  <input name="comenter" type="submit" value="Comenter" />
                  <input name="vider" type="reset"  value="Vider"/>
                  </td>
              </tr>
            </table>    
            <br/><br/>
            </form>

              
              </td>
            </tr>
            
        </table>
        <td width="77%">
        <?php include_once("template_menu_right.php"); ?>
        </td>
        
        <tr>
          <td>          
      
        
        </td>
        
      </tr>
    </table>

  </div>
  <?php  include_once("template_footer.php");?>
</div>

</body>
</html>
