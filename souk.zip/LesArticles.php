<?php 
include"storescripts/connect_to_mysql.php";
include"storescripts/session_func.php";
// pour la deconnexion
if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
	 /* header("location:../index.php"); */
}
?>
<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;-&nbsp;'.$date_; 
include"storescripts/connect_to_mysql.php";
//---------------------------------------------------------
include"storescripts/pagination_articles.php";




///Afficage des article (outputList)
if($productCount>0){
   while($row=mysql_fetch_array($sql2)){
      $id_get=$row["id"];
	  $category=$row["category"];
	  $price=$row["price"];
	  $like=$row["like_p"];
	  $dislike=$row["dislike_p"];
	  $product_name=$row["product_name"];
	  $heure_ajoute=$row["heure_ajoute"];
	  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
	  $outputList.='<table width="95%" border="0" cellspacing="0" cellpadding="6">
          <tr>
           <td width="31%" height="100"><a href="product.php?id_get='.$id_get.'"><img src="inventory_images/'.$id_get.'.jpg" alt="'.$product_name.'"  width="120" height="80" border="0" /></a>			</td>
            <td width="50%" valign="top"><br /><font size=4>'.$product_name.'</font><br />
              '.$price.'&nbsp;DA<br />
              <a href="product.php?id_get='.$id_get.'">Afficher l&acute;Article </a><br />
			  <em><font size=1>'.$date_added.'&nbsp;|&nbsp;'.$heure_ajoute.'&nbsp;|&nbsp;Like('.$like.')&nbsp;Dislike('.$dislike.')</font></em>
			  </td>
          </tr>
        </table><hr style="margin-right:15px;" color="#0099CC" "/>';
   }
}
else{
$outputList="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AUCUN ARTICLE !!";
}
mysql_close();


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=cp-1256" />
<title>Tout les articles dans le site a partir des categorie</title>
<div>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
</head>

<body>
</div>
<?php  include_once("template_header.php");?>
</div>
<div align="center" id="mainWrapper">
  <div id="pageContent" >
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
      	<td width="44%"><div id="cat_title_Div">&nbsp;&nbsp; <a href="LesArticles.php">Articles</a> &gt;&gt; <a href="?idCat=<?php echo $id_categorie1 ?>"><?php echo $cat_name1?></a> &gt;&gt; <a href=""><?php echo $subcat_name?></a></div></td>
        <td width="56%"><div id="rech_user_div" align="right">
          <form action="search.php" method="post">
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp; <a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp; <a  href="index.php?out">Deconnexion </a>
            <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
            <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />
          </form>
        </div></td>
        
      </tr>
    </table>
      
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr valign="top">
        <td width="12%" height="248" rowspan="2">
          <?php  include_once("template_menu_left.php") ?></td>
        <td width="88%" rowspan="2"><br/>
          <br/>
          <font color="#006699" size="4"><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voici les articles: </strong></font><br/>
          <br/>
          <div id="pagination_div" style="margin-left:50px">
            <?php 
		  $info_pagi='&nbsp;&nbsp;&nbsp;&nbsp;'. $paginationDisplay.'&nbsp;&nbsp;|&nbsp;<font size=2> Page  '. $pn .'  sur  '. $lastPage. '&nbsp;  |&nbsp;  Tous les Items:   ' . $productCount; 
		  
		  echo $info_pagi;
		  ?>
          </div>
          <div id="one_prod" style="margin-left:50px;margin-right:50px">
            <?php echo $outputList; ?>
          </div>
          <div id=pagination_div style="margin-left:50px"> <?php echo $info_pagi;?> </font></div>
        <br/><br/><br/><br/><br/></td>
        <td width="88%" rowspan="2">
        <?php  include_once("template_menu_right.php");?>
          </td>
      </tr>
    </table>
  </div>
  <?php  include_once("template_footer.php");?>
</div>
</body>
</html>
