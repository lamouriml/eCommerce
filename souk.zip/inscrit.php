<?php
//les fonction de verif le inscription

function checkPass( $password , $password2 )
    {
		if( $password == $password2 )
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }

//--------------------------------------------------------------------	
	function verifEmail( $email , $email2 )
    {
    	if( $email == $email2 )
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------	
    function checkUser( $username )
    {
    	$sql01 = "SELECT username FROM admin WHERE username = '$username' ";
        $result01 = mysql_query( $sql01 );
		$user_match = mysql_num_rows($result01);
        if( $result01 )
        {
        	if($user_match>0)
            {
            	return false;
            }
            else
            {
            	return true;
            }
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------
    function checkEmail( $email )
    {
    	$sql02 = "SELECT email FROM admin WHERE email = '$email' ";
        $result02 = mysql_query( $sql02 );
		$email_match = mysql_num_rows($result02);
        if( $result02 )
        {
        	if($email_match>0)
            {
            	return false;
            }
            else
            {
            	return true;
            }
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------
	/*function checkValidEmail( $email )
    {
    	$exp = ' ^[a-zA-Z0-9_\-]+@[a-zA-Z0-9_]+\.[a-zA-Z0-9]+$ ';
        if(ereg($exp,$email))
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }*/
?>

<?php 


$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 
include"storescripts/session_func.php";
include "storescripts/connect_to_mysql.php";
// pour la deconnexion

if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
}
?>
<?php
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1');
?>

<?php
// parse le formulaire d'Ajoute une User
	$msg_err_username=' ';
	$msg_err_password=' ';
	$msg_err_email=' ';
	$msg_err=' ';

	$username="";
	$password="";
	$password2="";
	$nom= "";
	$prenom= "";
	$email= "";
	$email2= "";
	$pays= "---";
	$adresse="";
	$tel="";
	$question="";

		
if(isset($_POST['username'])){
			//Cr�ation d'un identifiant al�atoire
		for ($ligne=0;$ligne<30;$ligne++){
		@$session.=substr('0123456789AZERTYUIOPMLKJHGFDSQWXCVBN',(rand()%(strlen('0123456789AZERTYUIOPMLKJHGFDSQWXCVBN'))),1);
		}

	
	$username=mysql_real_escape_string($_POST['username']);
	$password=mysql_real_escape_string($_POST['pass1']);
	$password2=mysql_real_escape_string($_POST['pass2']);
	$nom= mysql_real_escape_string($_POST['nom']);
	$prenom= mysql_real_escape_string($_POST['prenom']);
	$email= mysql_real_escape_string($_POST['email']);
	$email2= mysql_real_escape_string($_POST['email2']);
	$pays= mysql_real_escape_string($_POST['pays']);
	$adresse= mysql_real_escape_string($_POST['adresse']);
	$tel= mysql_real_escape_string($_POST['tel']);
	$question= mysql_real_escape_string($_POST['question']);
	//$password_crypt=md5($password);
	
	$sql0= mysql_query("select * from admin where username='$username' LIMIT 1");
		
	if( $username && $password && $password2 && $email && $email2 && $nom && $prenom && $pays && $adresse && $tel && $question)
    {
    	if( checkUser( $username ) && strlen($username) < 15  )
        {
        	if( checkPass( $password , $password2 ) && strlen($password) > 5 && strlen($password2) > 5 )
            {
            	if(checkEmail( $email ) && verifEmail( $email , $email2 )/* && checkValidEmail($email)*/ )
                {
                    $sql1=mysql_query("  insert into admin (session,username,password,nom,question,prenom,email,pays,adresse,tel,last_log_date) VALUES 	('$session','$username','$password','$nom','$question','$prenom','$email','$pays','$adresse','$tel',now() )  ") or die(mysql_error());
                    
					if( $sql1 )
                    {
					header("location:Inscrit_valide.php");
					exit();
					 }
                    else
                    {
                    	$msg_err="<div id='pagination_div' style='background:#FFA4A4; border:solid 1px #000000; ' >* Il ya une erreur (dans la requete ) , entrer les information complet !<br/> </div>";
                    }
                }
                else
                {
                    $msg_err_email="<div id='pagination_div' style='background:#FFA4A4; border:solid 1px #000000; ' >* Il ya une ereure dans la confirmation de l'adresse Mail ! <br/>* ou l'adresse Mail d�j� existe dans la base de donnee !<br/>* ou le format d'�criture de l'adresse Mail est incorrect !<br/></div>
                     ";
                }
            }
            else
            {
                $msg_err_password= " <div id='pagination_div' style='background:#FFA4A4; border:solid 1px #000000; ' >* Il ya une ereure dans la confirmation du mot de passe !</div>";
            }
        }
        else
        {
           $msg_err_username="<div id='pagination_div' style='background:#FFA4A4; border:solid 1px #000000; ' >* ce Username est d�j� utilis� ou ne correspond pas aux exigences de l'administrateur </div>" ;
        }
    }
    else
    {
        $msg_err=" <div id='pagination_div' style='background:#FFA4A4;border:solid 1px #000000;'>* svp remplir tout les cas de la formulaire !! </div>";
    }
 }
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Inscrit maintenant dans la site</title>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>

</head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header.php");?>

<div id="pageContent">
<div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
     <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  </form>
     </div>  
  <br/>
  <h2 class="Style1">S'inscrire � la Site de Toyour store</h2>
   <br/><br/><div align="left" style="margin-left:200px ;margin-right:300px ; " >  <font  color="#000000" size="4"><?php echo $msg_err;  ?></font></div>  <br/><br/>
<form id="templatemo_search" name="myform" method="post" action="inscrit.php" enctype="multipart/form-data">
<fieldset class="fieldset">
	  <legend><strong>Username</strong></legend>
				<table cellpadding="0" cellspacing="3" border="0" width="608">
				<tbody><tr>
					<td>Veuillez indiquer le Username que vous souhaitez utiliser
					<li style="margin-left:10px">N'utlise pas les chifres arabe</li>
                    <li style="margin-left:10px">La taille maximale est 15 caract�re</li>
                    
                    </td>
				</tr>
				<tr>
					<td>
						Le Username:<br>
				  <input name="username" type="text" class="iscritfield" dir="ltr" value="<?php echo $username ?>" size="50" maxlength="50"><br>						</td>
				  </tr>
                <tr>
					<td><font color="#000000" size="2"><?php echo $msg_err_username;  ?></font> </td>
				</tr>
				
				</tbody></table>
			</fieldset>

<fieldset class="fieldset" >
				<legend ><strong>Mot de passe</strong></legend>
				<table cellpadding="0" cellspacing="3" border="0" width="608" >
				<tbody><tr>
					<td colspan="2">Veuillez ins�rer un mot de passe pour votre compte utilisateur. 
                    
                    <li style="margin-left:20px">La taille Minimale est 5 caract�re</li>
                    </td>
				</tr>
				<tr>
					<td width="170">
						Mot de passe:<br>
						<input name="pass1" type="password" class="iscritfield" dir="ltr" value="" size="25" maxlength="50">
					</td>
					<td width="345">
						Confirmez votre Mot de passe:<br>
						<input type="password" class="iscritfield" name="pass2" size="25" maxlength="50" value="" dir="ltr">
					</td>
				</tr>
                <tr>
					<td colspan="2"><font color="#000000" size="2">
                    <?php echo $msg_err_password; ?>
                    </font> </td>
				</tr>
				
				</tbody></table>
			</fieldset>
            </fieldset>

            <fieldset class="fieldset">
				<legend><strong> &nbsp;E-Mail </strong>
				</legend><table cellpadding="0" cellspacing="3" border="0" width="608">
				<tbody><tr>
					<td colspan="2">Veuillez ins�rer une adresse email valide. </td>
				</tr>
				<tr>
					<td width="170">
						Adresse email:<br>
					  <input name="email" type="email" class="iscritfield" dir="ltr" value="<?php echo $email ?>" size="25" maxlength="50">
					</td>
					<td width="345">
						Confirmez votre Adresse email:<br>
					  <input type="email" class="iscritfield" name="email2" size="25" maxlength="50" value="<?php echo $email2 ?>" dir="ltr">
					</td>
				</tr>
                <tr>
					<td colspan="2"><font color="#000000" size="2">
                    <?php echo $msg_err_email;?>
                    </font>
                    </td>
				</tr>
				
				</tbody></table>
	</fieldset><br/>
            
            <fieldset class="fieldset">
				<legend><strong>Nom et Prenom</strong></legend>
				<table cellpadding="0" cellspacing="3" border="0" width="608">
				<tbody><tr>
					<td colspan="2">Ces champs est facultatif. Si vous le remplissez, merci de mettre une information exacte. </td>
				</tr>
				<tr>
					<td width="170">
						Nom:<br>
						<input name="nom" type="text" class="iscritfield" dir="ltr" value="<?php echo $nom ?>" size="25" maxlength="50">
					</td>
					<td width="345">
						Prenom:<br>
						<input type="text" class="iscritfield" name="prenom" size="25" maxlength="50" value="<?php echo $prenom ?>" dir="ltr">
					</td>
				</tr>
				
				</tbody></table>
	</fieldset>

<fieldset class="fieldset">
		<legend><strong>L'Adresse &amp; Telephone</strong></legend>
				<table cellpadding="0" cellspacing="3" border="0" width="608">
				<tbody>
				<tr>
					<td width="262">
					Les 48 willayat dans l'Algerie:<br>
	  <select name="pays" class="iscritfield" >
      <option value="<?php echo $pays ?>" selected="selected"><?php echo $pays ?></option>
  <option value="Adrar" >Adrar </option>
  <option value="Ain Defla" >Ain Defla</option>
  <option value="Ain Timouchent" >Ain Timouchent</option>
  <option value="Alger" >Alger </option>
  <option value="Annaba" >Annaba</option>
  <option value="Batna" >Batna</option>
  <option value="Bechar" >Bechar</option>
  <option value="Bejaia" >Bejaia</option>
  <option value="Belabbes" >Belabbes</option>
  <option value="Biskra" >Biskra</option>
  <option value="Blida" >Blida</option>
  <option value="Bordj bouarredj" >Bordj bouarredj</option>
  <option value="Bouira" >Bouira</option>
  <option value="Boumerdes" >Boumerdes</option>
  <option value="Chlef" >Chlef</option>
  <option value="Constantine" >Constantine</option>
  <option value="Djelfa" >Djelfa</option>
  <option value="El Bayadh" >El Bayadh</option>
  <option value="El Oued" >El Oued</option>
  <option value="El Taref" >El Taref</option>
  <option value="Ghardaia" >Ghardaia</option>
  <option value="Guelma" >Guelma</option>
  <option value="Illizi" >Illizi</option>
  <option value="Jijel" >Jijel</option>
  <option value="Khenchela" >Khenchela</option>
  <option value="Laghouat" >Laghouat</option>
  <option value="M'sila" >M'sila </option>
  <option value="Mascara" >Mascara</option>
  <option value="Medea" >Medea</option>
  <option value="Mila" >Mila</option>
  <option value="Mostaganem" >Mostaganem</option>
  <option value="Naama" >Naama</option>
  <option value="Oran" >Oran</option>
  <option value="Ouargla" >Ouargla</option>
  <option value="Oum el Bouaghi" >Oum el Bouaghi</option>
  <option value="Relizane" >Relizane</option>
  <option value="Saida" >Saida</option>
  <option value="Setif" >Setif</option>
  <option value="Skikda" >Skikda</option>
  <option value="Souk Ahras" >Souk Ahras</option>
  <option value="Tamanrasset" >Tamanrasset</option>
  <option value="Tebessa" >Tebessa</option>
  <option value="Tiaret" >Tiaret</option>
  <option value="Tindouf" >Tindouf</option>
  <option value="Tipaza" >Tipaza</option>
  <option value="Tissemsilt" >Tissemsilt</option>
  <option value="Tizi ouzou" >Tizi ouzou</option>
  <option value="Tlemcen" >Tlemcen</option>

 </select>
					</td>
                    <td width="337">
						Adresse complet:<br>
						<input type="text" class="iscritfield" name="adresse" size="50" maxlength="60" value="<?php echo $adresse ?>" dir="ltr">
					</td>
					
				</tr>
				<tr>
				  <td  colspan="2">Le numero de telephone:</td>
				  </tr>
				<tr >
				  <td  colspan="2">+213
                  <input name="tel" type="text" class="iscritfield" id="tel" dir="ltr" value="<?php echo $tel ?>" size="25" maxlength="50" /></td>
				  </tr>
				
				</tbody>
				</table>
	</fieldset>
    <fieldset class="fieldset">
		<legend><strong>Reponse de Securit�</strong></legend>
				<table cellpadding="0" cellspacing="3" border="0" width="608">
				<tbody><tr>
					<td colspan="2"> 
                    <li style="margin-left:10px">Ces champs est pour le cas de perdu du mot de passe</li>
                    <li style="margin-left:10px">Ecrire n'importe quel chose </li>
                     </td>
				</tr>
				<tr  colspan="2">
				  <td ><br>
					  <input name="question" type="text" class="iscritfield" dir="ltr" value="<?php echo $question ?>" size="40" maxlength="70">
				  </td>
					
				</tr>
				
				</tbody></table>
	</fieldset>
    
    <br /><table width="50%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><input name="inscrit" type="submit"  class="inscrit_btn" value="Terminer l&#39;inscription" />&nbsp;&nbsp;
      
<input name="reset" type="reset" class="inscrit_btn" value="R�initialiser les champs" /></td>
  </tr>
</table>

    
</form>
<br/><br/><br/><br/>
</div>
</div>

<?php  include_once("template_footer.php");?>

</div>
</body>
</html>
