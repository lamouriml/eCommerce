<?php 
	include"storescripts/connect_to_mysql.php"; 
	include"storescripts/session_func.php";
	include"storescripts/pagination_articles.php";
?>

<?php 
	error_reporting(E_ALL);
	ini_set('display_errors','1');  
?>

<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// Check see the URL variable 
// Select the Product Atrubute For View
$contact_div="";

if(isset($_GET['id_get'])){
    $id=$_GET['id_get'];
	$sql=mysql_query("select * from products,admin WHERE userId=idAdmin and id='$id' LIMIT 1");
	$productCount=mysql_num_rows($sql);
	if($productCount>0){
   		while($row=mysql_fetch_array($sql)){
	  		$category=$row["category"];
	   		$subcategory=$row["subcategory"];
			$details=$row["details"];
			$case=$row["product_case"];
			$price= $row["price"].'&nbsp;DA';
				if($row["price2"]!='0'){
	  			$priceOld='<del><font color="red">'.$row["price2"].' DA</font></del>';	
				}else{
					$priceOld='';
				}
			$product_name=$row["product_name"];
	  		$date_added=strftime("%d/%m/%Y",strtotime($row["date_added"]));
			$time_added=strftime("%H:%M:%S",strtotime($row["heure_ajoute"]));
			// user information contact
			$username=$row["username"];
			$nom=$row["nom"];
			$prenom=$row["prenom"];
			$email=$row["email"];
			$pays=$row["pays"];
			$adresse=$row["adresse"];
			$tel=$row["tel"];
			
			//////////////////////////
   		}
	}
	else{
   		echo "Cette article n existe pas!! ";
	}
}
else{
	echo "cette pagee est ingnorer dans le cas data renvoi";
}


// Afficher Commentaire 
			$liste_comm='';		
			$sql1=mysql_query("select * from comment_a WHERE id_a='".$id."' " ) or die(mysql_error());
			$CommCount=mysql_num_rows($sql1);
			if($CommCount>0){
   				while($row1=mysql_fetch_array($sql1)){
	  				$com_text_aff=$row1["com_text"];
	   				$com_title_aff=$row1["com_title"];
					$com_by_aff=$row1["com_by"];
					$com_date=$row1["com_date"];
					$com_time=$row1["com_time"];
					
					$liste_comm.="
					
					<font size='3'>&nbsp; By&nbsp;<strong><ins>$com_by_aff :</ins></strong></font> &nbsp;<strong>$com_title_aff</strong> 
         <br/>&nbsp;&nbsp;-  $com_text_aff<br/>
		 <font size='1'><em/>
         $com_date&nbsp;/&nbsp; $com_time<em/></font>
         <br/> -------------------------<br/>";
   				}
			}
			else{
			       $liste_comm='Pas de commentaire !!<br/><br/>';	
				}

		
/////////////////Like
$sql_like_aff=mysql_query("select like_p from products where id='".$id."' ") or die (mysql_error());
	$row_like=mysql_fetch_array($sql_like_aff);
	$like_p=$row_like['like_p'];
	if(isset($_GET['like']) ){
	$sql_like=mysql_query("update products set like_p=(like_p+1) where id='".$id."' ");	
	}
//////////////////  Dislike
$sql_dislike_aff=mysql_query("select dislike_p from products where id='".$id."' ") or die (mysql_error());
	$row_dislike=mysql_fetch_array($sql_dislike_aff);
	$dislike_p=$row_dislike['dislike_p'];
	if(isset($_GET['dislike']) ){
	$sql_dislike=mysql_query("update products set dislike_p=(dislike_p+1) where id='".$id."' ");
	}
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $product_name; ?></title>

<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>


</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header.php");?>
  <div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;<strong> '.$product_name.'  </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
     <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  </form>
     </div>  
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      
      </tr>
      <tr valign="top">
        <td width="21%" height="248">
            
       <?php  include("template_menu_left.php") ?>
      
        </td>
       
        <td width="47%"><h2 align="centre"> <font color="#FF6600"><BR/><BR/><BR/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font><font color="#006699" size="+2"><strong><?php echo $product_name ?></strong></font></h2>
          <table width="100%" height="400" border="0" cellpadding="10" cellspacing="5" align="left">
            <tr>
              <td width="46%" height="174" align="left">
              <a href="inventory_images/<?php echo $id; ?>.jpg"><img src="inventory_images/<?php echo $id; ?>.jpg" alt="$<?php echo $product_name; ?>" width="248" height="161" border="1" /></a>
              
          
                <div>
                &nbsp;(<?php echo $like_p ?>)<a href="?id_get=<?php echo $id ?>&like"><img src="images/simple_btn/like.png" width="25" height="25" /></a>&nbsp;&nbsp;&nbsp;(<?php echo $dislike_p ?>)<a href="?id_get=<?php echo $id ?>&dislike"><img src="images/simple_btn/like_not.png" width="25" height="25" /></a>
                
                &nbsp;
                &nbsp;
                
                <a href="commente.php?id_com_get=<?php echo $id?> "><img src="images/simple_btn/comment.png" alt="Ajouter Commentaire" width="32" height="32"  /></a>Commente </div>
              </td>
              <td width="54%" align="left" valign="top"  >
              <fieldset class='fieldset_comm' style='margin-right:5px'>
  <legend><font size="2">L'information de contacte:</font></legend>
	  <table width="89%" border="0" cellspacing="0" cellpadding="0">
	    <tr>
	      <td align="left">Ajouter Par&nbsp;:<font size="4"></font>
          <strong><?php echo $username; ?></strong>
          </td>
	      </tr>
	    <tr>
	      <td width="44%" align="left"></td>
	      </tr>
	    <tr>
	      </tr>
	    <tr>
	      <td align="left">Ajouter en&nbsp;:<font size="2"><?php echo $date_added."&nbsp;/&nbsp;".$time_added; ?></font></td>
	      </tr>
	    <tr>
	      </tr>
	    </table>
	  
     <hr  color="#FFCC66"/>
	     <?php echo 
		 "Nom: $nom&nbsp;$prenom <br />  
	      Adresse : $adresse <br />
		  Willaya :$pays <br />
          Telephone : $tel <br />
          E-Mail : $email "?>
	    </fieldset> 

              </td>
            </tr>
            <tr>
              <td height="174" colspan="2" align="left"><p>
                
              
              <div id="one_prod" style="margin-right:0px">
                <table width="100%" border="0" cellspacing="10" cellpadding="10">
                  <tr>
                    <td width="26%" align="right"><em><strong>Case:</strong></em> &nbsp;</td>
                    <td width="74%" ><?php echo $case  ?></td>
                  </tr>
                  
                  <tr>
                    <td width="26%" align="right"><em><strong>Categorie:</strong></em> &nbsp;</td>
                    <?php 
						$sql_nom_cat=mysql_query("select cat_name from categorie where id_categorie=$category  ");
						$fetch_sql_nom_cat=mysql_fetch_array($sql_nom_cat);
						$cat_name_prod=$fetch_sql_nom_cat['cat_name'];
					?>
                    <td width="74%" ><?php echo $cat_name_prod  ?></td>
                  </tr>
                  <tr>
                    <td align="right"><em><strong>Sous Cat:</strong></em>&nbsp;</td>
                    <?php 
						$sql_nom_subcat=mysql_query("select subcat_name from subcategorie where id_subcategory=$subcategory  ");
						$fetch_sql_nom_subcat=mysql_fetch_array($sql_nom_subcat);
						$subcat_name_prod=$fetch_sql_nom_subcat['subcat_name'];
					?>
                    <td><?php echo $subcat_name_prod ?></td>
                  </tr>
                  <tr>
                    <td align="right"><strong><em>Prix:</em></strong>:</td>
                    <td><?php echo $priceOld ?> &nbsp;&nbsp;<?php echo $price ?> </td>
                  </tr>
                  <tr valign="top">
                    <td align="right"><strong><em>Description:</em></strong></td>
                    <td><?php echo $details ?>
                    </td>
                  </tr>
                </table>
              </div><br/>
              <strong>Les Commentaire</strong><br/><br/>
              <div style="margin-right:50px;margin-left:50px;">
              
              <?php echo $liste_comm ?>
              </div>
              
              
            <br />
                <br />
        
              </td>
            </tr>
            
        </table>
        <td width="10%"> <?php  include_once("template_menu_right.php");?>
        
        </td>
        
        <tr>
          <td>          
      
        
        </td>
        
        
        
        
        
      </tr>
    </table>
 
  </div>
  </div>
  <?php  include_once("template_footer.php");?>
</div>

</body>
</html>
