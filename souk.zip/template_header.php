<style type="text/css">

<!--
.ddsmoothmenu ul{
	z-index:100;
	margin: 0;
	padding: 0;
	list-style-type: none;
}

/*Top level list items*/
.ddsmoothmenu ul li{
	position: relative;
	display: inline;
	float: left;
}

/*Top level menu link items style*/
.ddsmoothmenu ul li a {
	display: block;
	padding: 0 30px;
	height: 40px;
	line-height: 40px;
	margin-right: 1px;
	font-size: 12px;
	color: #ccc;	
	text-decoration: none;
	outline: none;
	text-align: center;
	
}

* html .ddsmoothmenu ul li a{ /*IE6 hack to get sub menu links to behave correctly*/
display: inline-block;
}

 .ddsmoothmenu ul li a:hover { /*CSS class that's dynamically added to the currently active menu items' LI A element*/
	color: #fff;
	background: #333

}

/*1st sub level menu*/
.ddsmoothmenu ul li ul {
	position: absolute;
	left: 0;
	padding: 10px 0 0;
	display: none; /*collapse all sub menus to begin with*/
	visibility: hidden;
	background: #313131;
	border-bottom: 4px solid #000
}

/*Sub level menu list items (undo style from Top level List Items)*/
.ddsmoothmenu ul li ul li{
display: list-item;
float: none;

}

/*All subsequent sub menu levels vertical offset after 1st level sub menu */
.ddsmoothmenu ul li ul li ul{
top: 0;
}

/* Sub level menu links style */
.ddsmoothmenu ul li ul li a{
	font-weight: 400;
	width: 130px; /*width of sub menus*/
	height: 30px;
	padding: 0 30px;
	line-height: 30px;
	font-size: 11px;	
	text-align: left;
	background: none;
	color: #ccc;
	border-bottom: 1px solid #444;
	border-top: 1px solid #222;

}

.ddsmoothmenu ul li ul li a.selected, .ddsmoothmenu ul li ul li a:hover {
	color: #fff;
	font-weight: 700;
	background: #222;
}

/* Holly Hack for IE \*/
* html .ddsmoothmenu{height: 1%;} /*Holly Hack for IE7 and below*/


/* ######### CSS classes applied to down and right arrow images  ######### */

.downarrowclass{
position: absolute;
top: 12px;
right: 7px;
}

.rightarrowclass{
position: absolute;
top: 6px;
right: 5px;
}

/* ######### CSS for shadow added to sub menus  ######### */

.ddshadow{
position: absolute;
left: 0;
top: 0;
width: 0;
height: 0;
}
.toplevelshadow{ /* shadow opacity. Doesn't work in IE*/
opacity: 0.5;
}

#pageHeader{
	background: #036;
	margin:0 ;
	padding:0;}

#top_nav{
	background: url(images/banner/menu_bg.png);
	margin:0 ;
	padding:0;
	}
	
	
	
-->
</style>




<div align="center" id="mainWrapper">

  <div id="pageHeader" >
  <table width="100%" height="37%" border="0">
  <tr>
    <td width="547" height="86"><div align="left">
      <h1><img src="images/LOGO.png" width="833" height="190" alt="logo" /></h1>
     
    </div></td>
    <td width="200"  >
   
    </td>
  </tr>
  <tr>
    <td height="21" colspan="2">
    <div id="top_nav" class="ddsmoothmenu">
            <ul>
              <li>
                <a href="index.php"><strong>ACCEUIL</strong></a>
              </li>
              <li>
                <a href="LesArticles.php"><strong>ARTICLES</strong></a>
              </li>
              <li>
                <a href="apropos.php"><strong>AIDE</strong></a>
              </li>
              <li>
                <a href="contact.php"><strong>CONTACT</strong></a>
              </li>
              <li>
                <a href="news.php"><strong>JOURNALE</strong></a>
              </li>
              
              <li>
                <a href="telecharge.php"><strong>TELECHARGE</strong></a>
              </li>
              <li>
                <a href="#"><strong>FORUME</strong></a>
              </li>
            </ul>
            <br style="clear:left " />
</div></td>
    </tr>
</table>
  </div>

