<?php 
include"storescripts/session_func.php";
// pour la deconnexion
if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
	 /* header("location:../index.php"); */
}
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Aide et Presentation de site</title>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>

</head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header.php");?>

<div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
         <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />     </form>
     </div>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    <td width="81%"  align="center" ><table width="100%" border="0" cellspacing="0" cellpadding="0" >
      <tr> </tr>
      <tr>
        <td width="20%"  align="justify" ><?php  include_once("template_menu_left.php");?></td>
        <td width="81%"  align="center" ><h1> <font color="#006699" >Presentation de site:</font></h1>
          <h3 >Ce site est cre&eacute; pur facilite les interaction <br/>
            et le cimmunication entre<br/>
            les personne qui vous aver payer ou achter des article.<br/>
            Nous regarde pas le cas de l'article soit<br/>
            nouveaux ou moyenne ou entiene.<br/>
            Et le site est organiser par des categorie pour <br/>
            simplifier le recherche ,en plus tous les article<br/>
            est capturer par de photos.<br/>
            En fin je merci tout les visiteur ou<br/>
            l'utilisateurs qui utilise mon site. <br/>
          </h3></td>
        <td width="20%"  align="justify" ><?php  include_once("template_menu_right.php");?></td>
      </tr>
      <tr>
        <td></td>
        <td></td>
      </tr>
    </table></td>
  </tr>
  </table>
  <BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/>
</div>

<?php  include_once("template_footer.php");?>
</div>
</body>
</html>
