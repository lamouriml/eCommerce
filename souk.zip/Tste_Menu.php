<?php 
include"storescripts/connect_to_mysql.php";
include"storescripts/session_func.php";
// pour la deconnexion
if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
	 /* header("location:../index.php"); */
}
?>
<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// Pour selectioner les 6 dernier article dans ot_SOUK
include"storescripts/connect_to_mysql.php";

//////////////////////// la pagination /////////////////////////////
$outputList="";
$sql = mysql_query("SELECT * FROM products")or die(mysql_error);
$productCount = mysql_num_rows($sql); 

if (isset($_GET['pn'])) { 
    $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); 
} else {     $pn = 1;
} 
$itemsPerPage = 3; 
$lastPage = ceil($productCount / $itemsPerPage);
if ($pn < 1) { 
    $pn = 1; 
} else if ($pn > $lastPage) { 
    $pn = $lastPage; 
} 

$centerPages = "";
$sub1 = $pn - 1;
$sub2 = $pn - 2;
$add1 = $pn + 1;
$add2 = $pn + 2;
if ($pn == 1) {
    $centerPages .=  $pn . ' &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
} else if ($pn == $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .=  $pn . ' &nbsp;';
} else if ($pn > 2 && $pn < ($lastPage - 1)) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .=  $pn . ' &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
} else if ($pn > 1 && $pn < $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= $pn ;
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
}
$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 

$sql2 = mysql_query("SELECT * FROM products order by id DESC $limit")or die(mysql_error); 

$paginationDisplay = ""; 
if ($lastPage != "1"){
    //$paginationDisplay .= 'Page <strong>' . $pn . '</strong> sur ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
    if ($pn != 1) {
        $previous = $pn - 1;
        $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> << </a> ';
    } 
    $paginationDisplay .=  $centerPages;
    if ($pn != $lastPage) {
        $nextPage = $pn + 1;
        $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn= ' . $nextPage . ' "> >> </a> ';
    } 
}

/////////////////////////////////////////////////////////////////////
///Afficage des article (outputList)
if($productCount>0){
   while($row=mysql_fetch_array($sql2)){
      $id_get=$row["id"];
	  $category=$row["category"];
	  $price=$row["price"];
	  $product_name=$row["product_name"];
	  $heure_ajoute=$row["heure_ajoute"];
	  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
	   $outputList.='<div id="one_prod"><table width="95%" border="0" cellspacing="0" cellpadding="6">
          <tr>
           <td width="31%" height="140"><a href="product.php?id_get='.$id_get.'"><img src="inventory_images/'.$id_get.'.jpg" alt="'.$product_name.'"  width="156" height="97" border="2" /></a>			</td>
            <td width="50%" valign="top"><br /><font size=4>'.$product_name.'</font><br />
              '.$price.'&nbsp;DA<br />
			  
              <a href="product.php?id_get='.$id_get.'">Afficher l&acute;Article </a><br />
			  <em><font size=1>'.$date_added.'&nbsp;/&nbsp;'.$heure_ajoute.'</font></em><br />
			  </td>
          </tr>
        </table></div><br/>';
   }
}
else{
$outputList="store est vide.AUCIN ARTICLE !!";
}
mysql_close();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tout les articles dans le site a partir des categorie</title>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
<div>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
</head>

<body>
</div>
  <?php  include_once("template_header.php");?>
</div>
<div align="center" id="mainWrapper">

  <div id="pageContent" >
   <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
         <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  
     </form>
    </div>  
    
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr valign="top">
        <td width="38%" height="248" rowspan="2">
        
           
            
             <div id="templatemo_menu" >
          <ul><br/>
<font size="5" color="#CCCCCC "><strong>&nbsp;&nbsp;&nbsp;Categorie</strong></font><br/><br/>          
		<?php 
		include"storescripts/connect_to_mysql.php";
		  $sql_cat=mysql_query("SELECT * from categorie" )or die(mysql_error) ;
		  while($res = mysql_fetch_array($sql_cat)){
		  ?>
             <li> <a href="articles_cat.php?desc=<?php echo $res['desc'] ?>"><?php echo $res['cat_name'] ?></a>
             </li>
            <?php }?> 
          </ul>
      </div>
      
      
		




        </td>
        <td width="62%" rowspan="2">
        <br/><br/><font color="#006699" size="5"><strong> &nbsp;&nbsp;Voici tous les articles: </strong></font><br/><br/>
          <div id="pagination_div">
			<?php 
		  $info_pagi='&nbsp;&nbsp;&nbsp;&nbsp;'. $paginationDisplay.'&nbsp;&nbsp;|&nbsp;<font size=2> Page  '. $pn .'  sur  '. $lastPage. '&nbsp;  |&nbsp;  Tous les Items:   ' . $productCount; 
		  
		  echo $info_pagi;
		  ?>
          
          </div>
          <br/>
		  <?php echo $outputList; ?>
          
          <div id=pagination_div>
		  <?php echo $info_pagi;?>
          </font></div>
        
        <p>
		
        </p>
        </td>
      </tr>
      
    </table>
	
  
  
  </div>
  <?php  include_once("template_footer.php");?>
</div>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>
