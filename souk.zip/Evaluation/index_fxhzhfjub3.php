<?php 
// Pour selectioner les 6 dernier article dans ot_SOUK
include"storescripts/connect_to_mysql.php";
 $dynamicList="";
$sql=mysql_query("select * from products ORDER BY date_added DESC LIMIT 6");
$productCount=mysql_num_rows($sql);

if($productCount>0){
   while($row=mysql_fetch_array($sql)){
      $id=$row["id"];
	  $category=$row["category"];
	   $price=$row["price"];
	  $product_name=$row["product_name"];
	  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
	  $dynamicList.='<table width="85%" border="1" cellspacing="0" cellpadding="6">
          <tr>
            <td width="31%" height="140"><a href="product.php?id='.$id.'"><img src="inventory_images/'.$id.'.jpg" alt="'.$product_name.'" width="156" height="97" border="2" /></a>			</td>
            <td width="69%" valign="top"><p>'.$product_name.'</p>
              <p>'.$price.'&nbsp;DA</p>
              <p><a href="product.php?id='.$id.'">Afficher la article </a></p></td>
          </tr>
        </table>';
   }
}
else{
$dynamicList="store est vide.AUCIN ARTICLE !!";
}
mysql_close();
?><!--MMDW 1 -->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html mmdw="0"  xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta mmdw="1"  http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Page d'Acceille</title>

<link mmdw="2"  href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>

<!--MMDW 2 --><style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style><!--MMDW 3 -->
</head>

<body>
<div mmdw="3"  align="center" id="mainWrapper">
<!--MMDW 4 --><?php  include_once("template_header.php");?><!--MMDW 5 -->
  <div mmdw="4"  id="pageContent">
    
    <p>&nbsp;</p>
	<div><span mmdw="5"  class="Style1"><a mmdw="6"  href="storeadmin/admin_login.php">vers login </a></span>-<strong><a mmdw="7"  href="storeadmin/index.php"> vers gestion admin</a></strong></div>
	<table mmdw="8"  width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr mmdw="9"  valign="top">
        <td mmdw="10"  width="23%" height="248"><p>&nbsp;</p>
        <p>&nbsp;</p>
        </td>
        <td mmdw="11"  width="46%"><p>les neuveux article dans le SOUK </p>
        <p><!--MMDW 6 --><?php echo $dynamicList; ?><!--MMDW 7 --></p>
        <!--<table width="85%" border="0" cellspacing="0" cellpadding="6">
          <tr>
            <td width="31%" height="140"><a href="product.php?"><img src="inventory_images/16.jpg" alt="$dynamicTitle" width="156" height="97" border="2" /></a>			</td>
            <td width="69%" valign="top"><p>Nom de l'article:</p>
              <p>Le prix:</p>
              <p><a href="product.php?">Afficher l'article </a></p></td>
          </tr>
        </table>-->
        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
        <td mmdw="12"  width="31%">&nbsp;</td>
      </tr>
    </table>
	<p>&nbsp;</p>
  </div>
  <!--MMDW 8 --><?php  include_once("template_footer.php");?><!--MMDW 9 -->
</div>
</body>
</html>
<!-- MMDW:success -->