<?php 
// pour la deconnexion
//$_dec=' ';  $_log=' ';  $_insc=' ';
include"storescripts/connect_to_mysql.php";
include"storescripts/session_func.php";
if(isset($_GET['out']) ){
		session_unset();
		session_destroy();
		//$_log='<a  href="storeadmin/admin_login.php">LogIn  </a>&nbsp;&nbsp;';
		//$_insc='<a href="inscrit.php">Inscrit</a>&nbsp;&nbsp;&nbsp;';
		header("location:index.php");
	}
	//else{
	//	$_dec='<a  href="index.php?dec"> Deconnexion  </a>';
		
	//	}
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// Pour selectioner les 3  article 1
 $dynamicList="";
$sql=mysql_query("select * from products ORDER BY id DESC LIMIT 4");
$productCount=mysql_num_rows($sql);

if($productCount>0){
   while($row=mysql_fetch_array($sql)){
      $id_get=$row["id"];
	  $category=$row["category"];
	  $price=$row["price"];
	  $product_name=$row["product_name"];
	  $heure_ajoute=$row["heure_ajoute"];
	  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
	  $dynamicList.='<table width="95%" border="0" cellspacing="0" cellpadding="6">
          <tr>
		  <font size=4>'.$product_name.'</font>
           <td width="15%" height="70"><a href="product.php?id_get='.$id_get.'"><img src="inventory_images/'.$id_get.'.jpg" alt="'.$product_name.'"  width="100" height="60" border="0" /></a>			</td>
            <td width="50%" valign="top">
              '.$price.'&nbsp;DA<br />
			  
              <a href="product.php?id_get='.$id_get.'">Detaille </a><br />
			  <em><font size=1>'.$date_added.'&nbsp;/&nbsp;'.$heure_ajoute.'</font></em><br />
			  </td>
          </tr>
        </table><hr style="margin-right:10px;" color="#0099CC" "/>';
   }
}
else{
$dynamicList="store est vide.AUCIN ARTICLE !!";
}

// Pour selectioner les 3  article 2
 $dynamicList2_="";
$sql2_=mysql_query("select * from products ORDER BY id DESC LIMIT 4,4");
$productCount2_=mysql_num_rows($sql2_);

if($productCount2_>0){
   while($row2_=mysql_fetch_array($sql2_)){
      $id_get2_=$row2_["id"];
	  $category2_=$row2_["category"];
	  $price2_=$row2_["price"];
	  $product_name2_=$row2_["product_name"];
	  $heure_ajoute2_=$row2_["heure_ajoute"];
	  $date_added2_=strftime("%d %b %Y",strtotime($row2_["date_added"]));
	  $dynamicList2_.='<table width="100%" border="0" cellspacing="0" cellpadding="6">
          <tr>
		  <font size=4>'.$product_name2_.'</font>
           <td width="15%" height="70"><a href="product.php?id_get='.$id_get2_.'"><img src="inventory_images/'.$id_get2_.'.jpg" alt="'.$product_name2_.'"  width="100" height="60" border="0" /></a>
            <td width="50%" valign="top">
              '.$price2_.'&nbsp;DA<br />
			  
              <a href="product.php?id_get='.$id_get2_.'">Detaille </a><br />
			  <em><font size=1>'.$date_added2_.'&nbsp;/&nbsp;'.$heure_ajoute2_.'</font></em><br />
			  </td>
          </tr>
        </table><hr style="margin-right:10px;" color="#0099CC" "/>';
   }
}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Totour Store Partous avec vous</title>

<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header.php");?>
  <div id="pageContent" >
    
   
      
       
      <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
<input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />       </form>
     </div>  
     
     
      
   
        
    <div id="pubDiv" align="centre"><img src="images/PUBL.jpg" width="1089" height="147" /> 
    </div>
    
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr valign="top">
        <td width="22%" height="248"><div> </div>
          <?php  include_once("template_menu_left.php") ?>
          
        <td width="62%"><div id="les6Div">
          <h2><font color="#FF6600"><strong>&nbsp;Les 8 Dernier Article Dans le Site&nbsp;:</strong></font></h2>
          <br />
          <div id="one_prod">
            <table width="500" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><?php echo $dynamicList?></td>
                <td><?php echo $dynamicList2_ ?></td>
              </tr>
            </table>
          </div>
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
          <br />
        </div>
        
        </td>
        <td width="16%"><?php  include_once("template_menu_right.php");?></td>
      </tr>
    </table>
	
  </div>
  <?php  include_once("template_footer.php");?>
</div></div>
</body>
</html>
