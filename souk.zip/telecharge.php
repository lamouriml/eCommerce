<?php 
include"storescripts/session_func.php";	
// pour la deconnexion
if(isset($_GET['dec'])){
      unset($_SESSION["id"]);
	  unset($_SESSION["manager"]);
	  unset($_SESSION["password"]);
	 /* header("location:../index.php"); */
}
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Aide et Presentation de site</title>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />

</head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header.php");?>

<div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
     <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  </form>
     </div>  
<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    <td width="20%"  ><?php  include_once("template_menu_left.php");?></td>
    <td width="60%">
     
     <h2 align="center">
         <font color="#0099FF" >Tel&eacute;chrgement:</font>
     </h2>
     <div align="center"> 
           <font color="#FF3300" >SOON ...</font>
     </div>
<ul><strong>Livres PDF,DOC...</strong>
         <li><a href="#">Programation</a></li>
         <li><a href="#">Islamique</a></li>
         <li><a href="#">Scientifique</a></li>
         </ul>
         <ul><strong>Application</strong>
         <li><a href="#">Economie</a></li>
         <li><a href="#">Etude</a></li>
         <li><a href="#">Software</a></li>
         </ul>
         <ul><strong>Diaporama</strong>
         <li><a href="#">Favorite</a></li>
         <li><a href="#">Islamique</a></li>
         <li><a href="#">Scientifique</a></li>
         </ul>
         <ul><strong>Flash</strong>
         <li><a href="#">Jeux</a></li>
         <li><a href="#">Intelegence</a></li>
         </ul>
         </td>
    <td width="20%"  ><?php  include_once("template_menu_right.php");?></td>
  </tr>
</table>
<BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/><BR/>
</div></div>

<?php  include_once("template_footer.php");?>
</div>
</body>
</html>
