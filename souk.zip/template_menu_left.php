<?php

// Random Automobile  
$randomProd2="";
	    include"storescripts/connect_to_mysql.php";
    	$sql_ran2=mysql_query("SELECT * from products where category=5 ORDER BY RAND() LIMIT 1" )or die(mysql_error) ;
	    while($row_ran2 = mysql_fetch_array($sql_ran2)){
			$id_ran2=$row_ran2['id'];
			$product_name2=$row_ran2['product_name'];
		 	$price2=$row_ran2['price'];
			$heure_ajoute2=$row_ran2["heure_ajoute"];
			$date_added2=strftime("%d %b %Y",strtotime($row_ran2["date_added"]));
$randomProd2="<table width='200' border='0' cellspacing='0' cellpadding='0' align='center' >
		  <tr>
			<td align='center'>
			<img src='inventory_images/$id_ran2.jpg' alt='$product_name2'  width='100' height='60' border='0' />
			</td>
		  </tr>
		   <tr>
			<td align='center'><strong>$product_name2</strong></td>
		  </tr>
		  <tr>
			<td align='center'>$price2&nbsp;DA&nbsp;|&nbsp;<a href='product.php?id_get=$id_ran2'>Plus</a> <br/>
			<font size=1><em>$date_added2&nbsp;|&nbsp;$heure_ajoute2</em> </font></td>
		  </tr>
		</table>";
  }?> 


<link href="style/Style.css" rel="stylesheet" type="text/css">

<!-- Menu 1 Category -->
<div id="template_menu_header" >
	<font size="4" color="#FFFFFF "><strong>&nbsp;&nbsp;&nbsp;Categorie</strong></font>	
</div>        
<div id="templatemo_menu" >       
<ul>	      
<?php 
	 include"storescripts/connect_to_mysql.php";
	$num_prod_cat="0";
	$sql_cat=mysql_query("SELECT * from categorie" )or die(mysql_error) ;
	 while($res = mysql_fetch_array($sql_cat)){
		$cat_name=$res['cat_name'];
		$id_categorie=$res['id_categorie'];	  
		$sql_num_prod_cat=mysql_query(" select * from products where category=$id_categorie ");
		$num_prod_cat=mysql_num_rows($sql_num_prod_cat);
		?>
             <li> <a href="LesArticles.php?idCat=<?php echo $id_categorie ?>" >	<strong><?php echo  $cat_name ?></strong> (<?php echo $num_prod_cat?>) </a>
             </li> 
 		<?php }?> 
   <hr color="#0099CC" style="margin-left:10px; margin-top:20px;margin-bottom:15px">
<?php 
 if(isset($_GET['idCat']) || isset($_GET['subCatId'])) {
	$id_categorie_get=$_GET['idCat'];
	$sql_subcat=mysql_query(" select * from subcategorie where id_category=$id_categorie_get ");
	while($res_subcat = mysql_fetch_array($sql_subcat)){
		$id_subcategorie=$res_subcat['id_subcategory'];
		$id_categorie1=$res_subcat['id_category'];
		$sql_num_prod_subcat=mysql_query(" select * from products where subcategory=$id_subcategorie ");
		$num_prod_subcat=mysql_num_rows($sql_num_prod_subcat);
		$subcatname=$res_subcat['subcat_name'];
		echo '<ol><a href="?idCat='.$id_categorie1.'&subCatId='.$id_subcategorie.'">'.$subcatname.'&nbsp;('. $num_prod_subcat.' )</a></ol>';
	}				  
 } 
 ?>
  </ul>
</div>


  <!--Menu 2 Random automobile-->
<div id="template_menu_header" >
	<font size="3" color="#FFFFFF ">
		<strong>&nbsp;&nbsp;&nbsp; Automobile</strong>
	</font>	
</div>        
<div id="templatemo_menu" >           
<?php echo $randomProd2 ?>
</div>