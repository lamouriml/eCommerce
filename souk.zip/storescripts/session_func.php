<?php 
session_start();
include"connect_to_mysql.php";
$active_sessions = 0;
$onlineCount="";
$minutes = 5; # period considered active
if($sid = session_id()) # if there is an active session
{
    # DB connect here
    $ip = $_SERVER['REMOTE_ADDR']; # Get Users IP address
    # Delete users from the table if time is greater than $minutes
    mysql_query("DELETE FROM `active_sessions` WHERE 
    `date` < DATE_SUB(NOW(),INTERVAL $minutes MINUTE)")or die(mysql_error()); 
    
    # Check to see if the current ip is in the table
    $sql = mysql_query("SELECT * FROM active_sessions WHERE ip='$ip'");
    $row = mysql_fetch_array($sql);
    # If the ip isn't in the table add it.
    if(!$row){
        mysql_query("INSERT INTO `active_sessions` (`ip`, `session`, `date`) 
        VALUES ('$ip', '$sid', NOW()) ON DUPLICATE KEY UPDATE `date` = NOW()")or die(mysql_error());
    }
    # Get all the session in the table
    $sessions = mysql_query('SELECT * FROM `active_sessions`')or die(mysql_error());
    # Add up all the rows returned
    $active_sessions = mysql_num_rows($sessions);
}
    # Print the final result
    $onlineCount="Online:$active_sessions";


///////////////////

$zone = "Asia/Qatar";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($zone);  

?>
