
<?  
//-------------------------------------------------------------------
     function checkPass( $password , $password2 )
    {
    	if( $password == $password2 )
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------	
	function verifEmail( $email , $email2 )
    {
    	if( $email == $email2 )
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------	
    function checkUser( $username )
    {
    	$sql01 = 'SELECT username FROM admin WHERE username = {$username} ';
        $result01 = mysql_query( $sql01 );
		$user_match = mysql_num_rows($result01);
        if( $result01 )
        {
        	if($user_match>0)
            {
            	return false;
            }
            else
            {
            	return true;
            }
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------
    function checkEmail( $email )
    {
    	$sql02 = 'SELECT email FROM admin WHERE email = {$email} ';
        $result02 = mysql_query( $sql02 );
		$email_match = mysql_num_rows($result01);
        if( $result02 )
        {
        	if($email_match>0)
            {
            	return false;
            }
            else
            {
            	return true;
            }
        }
        else
        {
        	return false;
        }
    }
//--------------------------------------------------------------------
	function checkValidEmail( $email )
    {
    	$exp = ' ^[a-zA-Z0-9_\-]+@[a-zA-Z0-9_]+\.[a-zA-Z0-9]+$ ';
        if( ereg( $exp , $email ) )
        {
        	return true;
        }
        else
        {
        	return false;
        }
    }

?>
