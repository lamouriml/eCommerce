 <?php 

$db_host = "sql300.hostkda.com";
$db_username = "hkda_17726067"; 
$db_pass = "azerty88"; 
$db_name = "hkda_17726067_souk";

// Run the actual connection here 
mysql_connect("$db_host","$db_username","$db_pass") or die ("could not connect to mysql");
mysql_select_db("$db_name") or die ("no database");  

$charsett = 'cp-1256';
mysql_query("SET NAMES '" . $charsett . "'");
mysql_query("SET character_set_client=" . $charsett . "");
mysql_query("SET character_set_connection=" . $charsett . "");
mysql_query("SET character_set_database=" . $charsett . "");
mysql_query("SET character_set_results=" . $charsett . "");
mysql_query("SET character_set_server=" . $charsett . ""); 

          
?>

