<?php 
$subCat_list="";
$cat_name="";
$subcat_name="";
if(isset($_GET['idCat'])){
	$id_cat_get=$_GET['idCat'];
	$sql_cat_title=mysql_query("SELECT * from categorie where id_categorie='$id_cat_get'" )or die(mysql_error) ;
	$row_cat_title=mysql_fetch_array($sql_cat_title);
	$cat_name1= $row_cat_title['cat_name']; 
	
	//------------------- la pagination IF ISSET LE GET de Cat -------------------------
	$outputList="";	
	$sql = mysql_query("SELECT * FROM products WHERE category='$id_cat_get' ")or die(mysql_error);
	$productCount = mysql_num_rows($sql); 

	if (isset($_GET['pn']) && isset($_GET['idCat'])  ) { 
		$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); 
		$idCat = preg_replace('#[^0-9]#i', '', $_GET['idCat']); 
		
	} else {     $pn = 1;
	} 
	$itemsPerPage = 3; 
	$lastPage = ceil($productCount / $itemsPerPage);
	if ($pn < 1) { 
		$pn = 1; 
	} else if ($pn > $lastPage) { 
		$pn = $lastPage; 
	} 
	$centerPages = "";
	$sub1 = $pn - 1;
	$sub2 = $pn - 2;
	$add1 = $pn + 1;
	$add2 = $pn + 2;
	if ($pn == 1) {
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.' ">' .$add1.'</a> &nbsp;';
	} else if ($pn == $lastPage) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.'&idCat='.$id_cat_get.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
	} else if ($pn > 2 && $pn < ($lastPage - 1)) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub2.'&idCat='.$id_cat_get.' ">'.$sub2.'</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.' ">'.$add1.'</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add2.'&idCat='.$id_cat_get.' ">'.$add2.'</a> &nbsp;';
	} else if ($pn > 1 && $pn < $lastPage) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.'&idCat='.$id_cat_get.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .= $pn ;
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.' ">'.$add1.'</a> &nbsp;';
	}
	$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
	$sql2 = mysql_query("SELECT * FROM products WHERE category='$id_cat_get' order by id DESC $limit ")/*or die(mysql_error)*/; 
	$paginationDisplay = ""; 
	if ($lastPage != "1"){
		//$paginationDisplay .= 'Page <strong>' . $pn . '</strong> sur ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
		if ($pn != 1) {
			$previous = $pn - 1;
			$paginationDisplay .=  '&nbsp;  <a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'&idCat='.$id_cat_get.' "> << </a> ';
		} 
		$paginationDisplay .=  $centerPages;
		if ($pn != $lastPage) {
			$nextPage = $pn + 1;
			$paginationDisplay .=  '&nbsp;  <a href="'.$_SERVER['PHP_SELF'].'?pn='.$nextPage.'&idCat='.$id_cat_get.' "> >> </a> ';
		} 
	}
}
//----------------------
else {
	//------------------- la pagination IF D'NOT LE GET -------------------------
	$outputList="";	
	$sql = mysql_query("SELECT * FROM products ")or die(mysql_error);
	$productCount = mysql_num_rows($sql); 
	$cat_name1="";
	if (isset($_GET['pn'])) { 
		$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); 
	} else {     $pn = 1;
	} 
	$itemsPerPage = 3; 
	$lastPage = ceil($productCount / $itemsPerPage);
	if ($pn < 1) { 
		$pn = 1; 
	} else if ($pn > $lastPage) { 
		$pn = $lastPage; 
	} 
	$centerPages = "";
	$sub1 = $pn - 1;
	$sub2 = $pn - 2;
	$add1 = $pn + 1;
	$add2 = $pn + 2;
	if ($pn == 1) {
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
	} else if ($pn == $lastPage) {
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
	} else if ($pn > 2 && $pn < ($lastPage - 1)) {
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
	} else if ($pn > 1 && $pn < $lastPage) {
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
		$centerPages .= $pn ;
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
	}
	$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
	$sql2 = mysql_query("SELECT * FROM products order by id DESC $limit ")/*or die(mysql_error)*/; 
	$paginationDisplay = ""; 
	if ($lastPage != "1"){
		//$paginationDisplay .= 'Page <strong>' . $pn . '</strong> sur ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
		if ($pn != 1) {
			$previous = $pn - 1;
			$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> << </a> ';
		} 
		$paginationDisplay .=  $centerPages;
		if ($pn != $lastPage) {
			$nextPage = $pn + 1;
			$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn= ' . $nextPage . ' "> >> </a> ';
		} 
	}
}





if(isset($_GET['subCatId'])  && isset($_GET['idCat'])){
		$id_subcat_get=$_GET['subCatId'];
		$id_cat_get=$_GET['idCat'];
		
		$sql_subcat_title=mysql_query("SELECT * from subcategorie where id_subcategory='$id_subcat_get' " )or die(mysql_error) ;
		$row_subcat_title=mysql_fetch_array($sql_subcat_title);
		$subcat_name=$row_subcat_title['subcat_name'];
		
		$sql_cat_title=mysql_query("SELECT * from subcategorie where id_category='$id_cat_get' " )or die(mysql_error) ;
		$row_cat_title=mysql_fetch_array($sql_cat_title);
	//	$cat_name=$row_cat_title['cat_name'];
		
//----------------------
//------------------- la pagination IF ISSET LE GET de Cat et le GET de SubCat -------------------------
	$outputList="";	
	$sql = mysql_query("SELECT * FROM products WHERE subcategory='$id_subcat_get' and category='$id_cat_get'")or die(mysql_error);
	$productCount = mysql_num_rows($sql); 

	if (isset($_GET['pn'])) { 
		$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); 
	} else {     $pn = 1;
	} 
	$itemsPerPage = 3; 
	$lastPage = ceil($productCount / $itemsPerPage);
	if ($pn < 1) { 
		$pn = 1; 
	} else if ($pn > $lastPage) { 
		$pn = $lastPage; 
	} 
	$centerPages = "";
	$sub1 = $pn - 1;
	$sub2 = $pn - 2;
	$add1 = $pn + 1;
	$add2 = $pn + 2;
	if ($pn == 1) {
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">' .$add1.'</a> &nbsp;';
	} else if ($pn == $lastPage) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
	} else if ($pn > 2 && $pn < ($lastPage - 1)) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub2.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$sub2.'</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .=  $pn . ' &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$add1.'</a> &nbsp;';
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$add2.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$add2.'</a> &nbsp;';
	} else if ($pn > 1 && $pn < $lastPage) {
		$centerPages .= '&nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$sub1.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$sub1.'</a> &nbsp;';
		$centerPages .= $pn ;
		$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'].'?pn='.$add1.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' ">'.$add1.'</a> &nbsp;';
	}
	$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
	$sql2 = mysql_query("SELECT * FROM products WHERE subcategory='$id_subcat_get'  and category='$id_cat_get' order by id DESC $limit "); 
	$paginationDisplay = ""; 
	if ($lastPage != "1"){
		//$paginationDisplay .= 'Page <strong>' . $pn . '</strong> sur ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
		if ($pn != 1) {
			$previous = $pn - 1;
			$paginationDisplay .='&nbsp;<a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' "> << </a> ';
		} 
		$paginationDisplay .=  $centerPages;
		if ($pn != $lastPage) {
			$nextPage = $pn + 1;
			$paginationDisplay .='&nbsp;<a href="'.$_SERVER['PHP_SELF'].'?pn='.$nextPage.'&idCat='.$id_cat_get.'&subCatId='.$id_cat_get.' "> >> </a> ';
		} 
	}

}


?>