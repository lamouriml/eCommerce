<?php 
include"storescripts/connect_to_mysql.php";
include"storescripts/session_func.php";	
//-------------------------------------
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

$msg_de_merci="";
if(isset($_POST['cont_nom'])){
	$est="no";
	$_cont_nom=mysql_real_escape_string($_POST['cont_nom']);
	$_cont_email=mysql_real_escape_string($_POST['cont_email']);
	$_cont_tel=mysql_real_escape_string($_POST['cont_tel']);
	$_cont_titre=mysql_real_escape_string($_POST['cont_titre']);
	$_cont_contenu=mysql_real_escape_string($_POST['cont_contenu']);
	$sql= mysql_query("INSERT INTO contact
	                  (cont_nom , cont_email , cont_tel , cont_titre , cont_contenu , cont_est_vue , cont_date) 
	                  VALUES 
	                  ('$_cont_nom' , '$_cont_email' , '$_cont_tel' , '$_cont_titre' , '$_cont_contenu' , '$est' , now() ) ") or die(mysql_error());
					  $msg_de_merci="Votre message � �te envoy� � l'administrateure,<br/> Merci boucoup ";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Contacter par les message avec Administrateur</title>
<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />

</head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header.php");?>

<div id="pageContent">

<div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        	<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
            <a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   /><input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  
     </form>
     </div>  


<table width="100%">
  <tr>
    <td width="20%" align="justify" ><?php  include_once("template_menu_left.php");?></td>   
    <td width="53%">
      <div id="content_left">
      <div id="contact_form">
      <font color="#009900"><strong ><h2 align="center"><?php echo $msg_de_merci ?></h2></strong></font>
        <h4>&nbsp;&nbsp;&nbsp;Envoyer votre message a L'administrateure pour questioner ou pour les conseille </h4>
        <form method="post" name="contact" id="ok" action="#">
          <label for="author">Nom:</label>
          <input type="text" id="cont_nom" name="cont_nom" class="required input_field" />
          <div class="cleaner_h10"></div>
          <label for="email">Email:</label>
          <input type="text" id="email" name="cont_email" class="validate-email required input_field" />
          <div class="cleaner_h10"></div>
          <label for="phone">Telephone:</label>
          <input type="text" name="cont_tel" id="phone" class="input_field" />
          <label for="phone">Titre:</label>
          <input type="text" name="cont_titre" id="phone" class="input_field" />
          <div class="cleaner_h10"></div>
          <label for="text">Message:</label>
          <textarea name="cont_contenu" cols="0" class="required" id="text"  onfocus="this.value=(this.value=='Ecrire votre message a  administrateur ici ...')? '' : this.value ;">Ecrire votre message a  administrateur ici ...</textarea>
          <div class="cleaner_h10"></div>
          <input type="submit" class="submit_btn float_l" name="envoi" id="submit" value="Envoyer" />
          <input type="reset" class="submit_btn float_r" name="reset" id="reset" value="Vider" />
        </form>
        <div class="content_box" style="margin-left:20px">
          <h2>Toyour Store</h2>
          
          <h4>Lam Moh Lam<br />
            Etudiant L3 SITW<br />
            Universit&eacute; de Constantine </h4>
          -----------------------------------------------------------------------------------      <p>Oum Thiour - El-Oued<br />
            Tel : (+213) 663258440<br />
            E-Mail : lamouriml@hotmail.com<br />
            Facebook : Facebook.com/Mohamed.Lam.Lam </p>
        </div>
      </div>
    </div>
      <font color="#FF3300" ><em><h3 align="center">&nbsp;</h3></em></font></p>
      </td>
    <td width="20%"><?php  include_once("template_menu_right.php");?></td>
  </tr>
</table>

</div>

<?php  include_once("template_footer.php");?>
</div>
</div></body>
</html>
