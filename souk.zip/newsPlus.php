<?php
// scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1'); 
include"storescripts/session_func.php";
?>

<?php
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

include"storescripts/connect_to_mysql.php"; 
// Check see th URL variable 
if(isset($_GET['idNews'])){
    
	$idNews=$_GET['idNews'];
	$sql=mysql_query("select * from news WHERE idNews='$idNews' LIMIT 1");
	$newsCount=mysql_num_rows($sql);
	if($newsCount>0){
   		while($row=mysql_fetch_array($sql)){
	  		$titre=$row["titre"];
	   		$tout=$row["tout"];
			$dateAjoute=strftime("%d %b %Y",strtotime($row["dateAjoute"]));
   		}
	}
	else{
   		echo "News n existe pas!! ";
	}
}
else{
	header("location:newsPlus.php");
	exit();
}
mysql_close();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $titre; ?></title>

<link href="style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="favicon.ico" rel="shortcut icon" />
<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style>
</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header.php");?>
  <div id="pageContent">
	<div id="rech_user_div" align="right">
        <form action="search.php" method="POST">
        <?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$onlineCount.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
        	<a  href="inscrit.php">Inscrit </a>&nbsp;&nbsp;&nbsp;
        	<a  href="storeadmin/admin_login.php">Login </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php?out">Deconnexion </a>          
   		 <input name="rech_btn" type="submit" value="Recherche"  id="search_btn"   />
     <input name="rech_txt" type="text" size="30"    id="search_txt" value="Rechercher" onfocus="this.value=(this.value=='Rechercher')? '' : this.value ;"  />  </form>
     </div>  
    
    <br /><br />
	
	<table width="100%" border="0" cellspacing="50" cellpadding="10">
      <tr valign="top">
        <td width="38%" height="248"><h2><a href="news_images/<?php echo $idNews; ?>.jpg"><img src="news_images/<?php echo $idNews; ?>.jpg" alt="$<?php echo $titre; ?>" width="292" height="177" border="2" /></a></h2></td>
        <td width="62%">
        <div id='titreNewsDiv' style="width:600px"><font color="#006699" size="+2"><strong><?php echo $titre; ?></strong></font></div>
          <div id="toutNewsDiv" >
          <?php echo nl2br($tout); ?>
          <em><h5><font color="#006699">Ajouter en: <?php echo $dateAjoute; ?></font></h5></em></div>
        </td>
      </tr>
    </table>
    
	<br /><br /><br /><br /><br /><br /><br /><br />
  </div>
  <?php  include_once("template_footer.php");?>
</div>
</body>
</html>
