<?php

// Random Informatique  
$randomProd="";
	    include"storescripts/connect_to_mysql.php";
    	$sql_ran=mysql_query("SELECT * from products where category=1 ORDER BY RAND() LIMIT 1" )or die(mysql_error) ;
	    while($row_ran = mysql_fetch_array($sql_ran)){
			$id_ran=$row_ran['id'];
			$product_name=$row_ran['product_name'];
		 	$price=$row_ran['price'];
			$heure_ajoute=$row_ran["heure_ajoute"];
			$date_added=strftime("%d %b %Y",strtotime($row_ran["date_added"]));
$randomProd="<table width='200' border='0' cellspacing='0' cellpadding='0' align='center' >
		  <tr>
			<td align='center'>
			<img src='inventory_images/$id_ran.jpg' alt='$product_name'  width='100' height='60' border='0' />
			</td>
		  </tr>
		   <tr>
			<td align='center'><strong>$product_name</strong></td>
		  </tr>
		  <tr>
			<td align='center'>$price&nbsp;DA&nbsp;|&nbsp;<a href='product.php?id_get=$id_ran'>Plus</a> <br/>
			<font size=1><em>$date_added&nbsp;|&nbsp;$heure_ajoute</em> </font></td>
		  </tr>
		</table>";
  }?> 

<link href="style/Style.css" rel="stylesheet" type="text/css">
<!--Menu 2-->
<div id="template_menu_header" >
	<font size="3" color="#FFFFFF ">
		<strong>&nbsp;&nbsp;&nbsp; Informatique</strong>
	</font>	
</div>        
<div id="templatemo_menu" >       
	      
<?php echo $randomProd ?>
</div>
<!-- ------------------------------------------------------------ -->

<!--Menu 1-->
<div id="template_menu_header" >
	<font size="3" color="#FFFFFF ">
		<strong>&nbsp;&nbsp;&nbsp; Statistics</strong>
	</font>	
</div>        
<div id="templatemo_menu" >       
&nbsp;&nbsp;&nbsp;&nbsp;<a href="storeadmin/perdu.php">Mot de passe perdu ?</a><br />
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Display Statistics</a><br />
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Browser Statistics</a><br />
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">OS Statistics</a><br />
&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">Users Statistics</a><br />
</div>
<!-- ------------------------------------------------------------ -->







