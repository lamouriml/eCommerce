<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php"; 
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
 ?>

<?php
// scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1'); 
?>

<?php 
//  assurer que le fourmulaire est plin de information
if(isset($_GET['uid']))
    {
    $targetID=$_GET['uid'];
	$sql=mysql_query("SELECT * FROM admin WHERE idAdmin='$targetID' ");
	$row=mysql_fetch_array($sql);
			$_username=$row["username"];
	   		$_password=$row["password"];
	  		$_nom=$row["nom"];
	  		$_prenom=$row["prenom"];
			$_email=$row["email"];
			$_tel=$row["tel"];
			$_pays=$row["pays"];
	   		$_adresse=$row["adresse"];
			$_estAdmin=$row["estAdmin"];
			$_question=$row["question"];
	}
 
// parse le formulaire MODIF une USER
if(isset($_POST['modif'])){
$uid=mysql_real_escape_string($_POST['thisID']);
$username0=mysql_real_escape_string($_POST['username']);
$password0=mysql_real_escape_string($_POST['pass1']);
$nom0= mysql_real_escape_string($_POST['nom']);
$prenom0= mysql_real_escape_string($_POST['prenom']);
$email0=mysql_real_escape_string($_POST['email']);
$pays0=mysql_real_escape_string($_POST['pays']);
$adresse0= mysql_real_escape_string($_POST['adresse']);
$tel0= mysql_real_escape_string($_POST['tel']);
$estAdmin0= mysql_real_escape_string($_POST['estAdmin']);
$question0= mysql_real_escape_string($_POST['question']);
$last_log_date= mysql_real_escape_string($_POST['last_log_date']);

$sql0= mysql_query("UPDATE admin SET username='$username0',password='$password0',nom='$nom0',question='$question0',prenom='$prenom0',
email='$email0',pays='$pays0',adresse='$adresse0',tel='$tel0',
estAdmin='$estAdmin0' WHERE idAdmin='$uid' LIMIT 1");


 header("location:user_list_admin.php");
 exit(); 

} 
?>
 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>user edit</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
    <div id="rech_user_div" align="right">
        <form action="#" method="POST">
        	<a  href="user_list_admin.php">Liste  </a>&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 
    
    
    <div style="margin-left: 24px" align="left">
      <h4><strong>la modification de l'Utilisateur correspondont : <?php echo $_nom;echo ' ';echo $_prenom;?></strong></h4>
      
      
      </div>
    <a name="inventoryForm"  id="inventoryForm"></a >
	<h2 class="Style1">
	  Modifier Les Profiles</h2>
	<form id="myform" name="myform" method="post" action="user_edit_admin.php" enctype="multipart/form-data">
<table width="100%" border="0">
<tr>
  <td><div align="right"><strong>Nom d'Utilisateur:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="username" type="text" class="iscritfield" value="<?php echo $_username ?>"   size="50" maxlength="30"/></td>
</tr>
<tr>
  <td><div align="right"><strong>Mot de psse:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="pass1" type="text" class="iscritfield" value= "<?php echo $_password ?>"  size="20" maxlength="20"/></td>
</tr>
</tr>
<tr>
  <td><div align="right"><strong>Reponse securit�:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="question" type="text" class="iscritfield" value= "<?php echo $_question ?>"  size="20" maxlength="20"/></td>
</tr>

<tr>
<td width="237">&nbsp;</td>
<td width="739">&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
  <td><div align="right">
    <div align="right"><strong>Nom:&nbsp;&nbsp;&nbsp;</strong></div>
  </div></td>
  <td><input name="nom" type="text" class="iscritfield" value="<?php echo $_nom ?>"  size="50" maxlength="30"/></td>
</tr>
<tr>
  <td><div align="right">
    <div align="right"><strong>Prenom:&nbsp;&nbsp;&nbsp;</strong></div>
  </div></td>
  <td><input name="prenom" type="text" class="iscritfield" value="<?php echo $_prenom ?>"  size="50" maxlength="30"/></td>
</tr>
<tr>
  <td class="Style1"><div align="right"><strong>E-Mail:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="email" type="text" class="iscritfield" value="<?php echo $_email?>"  size="50" maxlength="50"/></td>
</tr>
<tr>
  <td><div align="right"><strong>Willaya:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td>
     <select name="pays" class="iscritfield" >
      <option value="<?php echo $_pays ?>" selected="selected"><?php echo $_pays ?></option>
  <option value="Adrar" >Adrar </option>
  <option value="Ain Defla" >Ain Defla</option>
  <option value="Ain Timouchent" >Ain Timouchent</option>
  <option value="Alger" >Alger </option>
  <option value="Annaba" >Annaba</option>
  <option value="Batna" >Batna</option>
  <option value="Bechar" >Bechar</option>
  <option value="Bejaia" >Bejaia</option>
  <option value="Belabbes" >Belabbes</option>
  <option value="Biskra" >Biskra</option>
  <option value="Blida" >Blida</option>
  <option value="Bordj bouarredj" >Bordj bouarredj</option>
  <option value="Bouira" >Bouira</option>
  <option value="Boumerdes" >Boumerdes</option>
  <option value="Chlef" >Chlef</option>
  <option value="Constantine" >Constantine</option>
  <option value="Djelfa" >Djelfa</option>
  <option value="El Bayadh" >El Bayadh</option>
  <option value="El Oued" >El Oued</option>
  <option value="El Taref" >El Taref</option>
  <option value="Ghardaia" >Ghardaia</option>
  <option value="Guelma" >Guelma</option>
  <option value="Illizi" >Illizi</option>
  <option value="Jijel" >Jijel</option>
  <option value="Khenchela" >Khenchela</option>
  <option value="Laghouat" >Laghouat</option>
  <option value="M'sila" >M'sila </option>
  <option value="Mascara" >Mascara</option>
  <option value="Medea" >Medea</option>
  <option value="Mila" >Mila</option>
  <option value="Mostaganem" >Mostaganem</option>
  <option value="Naama" >Naama</option>
  <option value="Oran" >Oran</option>
  <option value="Ouargla" >Ouargla</option>
  <option value="Oum el Bouaghi" >Oum el Bouaghi</option>
  <option value="Relizane" >Relizane</option>
  <option value="Saida" >Saida</option>
  <option value="Setif" >Setif</option>
  <option value="Skikda" >Skikda</option>
  <option value="Souk Ahras" >Souk Ahras</option>
  <option value="Tamanrasset" >Tamanrasset</option>
  <option value="Tebessa" >Tebessa</option>
  <option value="Tiaret" >Tiaret</option>
  <option value="Tindouf" >Tindouf</option>
  <option value="Tipaza" >Tipaza</option>
  <option value="Tissemsilt" >Tissemsilt</option>
  <option value="Tizi ouzou" >Tizi ouzou</option>
  <option value="Tlemcen" >Tlemcen</option>

 </select></td>
</tr>
<tr>
<td><div align="right"><strong>Adresse:&nbsp;&nbsp;&nbsp;</strong></div></td>
<td><input name="adresse" type="text" class="iscritfield" value="<?php echo $_adresse ?>"  size="60" maxlength="60"/></td>
</tr>
<tr>
  <td><div align="right"><strong>Telephone :&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="tel" type="text" class="iscritfield" value="<?php echo $_tel; ?>"  size="20" maxlength="20"/></td>
</tr>
<tr>
  <td><div align="right"><strong>Est Admin ? :&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td>
    <select name="estAdmin" class="iscritfield" id="estAdmin">
      <option value="<?php echo $_estAdmin ?>"> <?php echo $_estAdmin; ?> </option>
      <option value="no">no</option>
      <option value="yes">yes</option>
    </select></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><p><br>
  <input name="thisID" type="hidden" value="<?php echo $targetID ?>" />
  <input type="submit"  name="modif" value="Applique" />
</p></tr>
</table>
</form>
  </div>
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
