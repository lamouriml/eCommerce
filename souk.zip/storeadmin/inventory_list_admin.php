<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";   
?>

<?php 
$time_ = date("H:i"); 
$date_ = date("Y/m/d");
$time_now = $time_.'&nbsp;--&nbsp;'.$date_; 

// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
/////////////////////////////////////////////////////

// l'ffichge des article
$product_list="";
$sql=mysql_query("select * from products,admin WHERE userId=idAdmin ORDER BY id DESC");
$productCount=mysql_num_rows($sql);

if($productCount>0){
while($row=mysql_fetch_array($sql)){
  $id=$row["id"];
  $category=$row["category"];
   $price=$row["price"];
  $product_name=$row["product_name"];
  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
  $AjouterPar=$row["username"];

  $tableAtt="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='2' cellpadding='0'  >
    <tr>
      <td width='7%'  bgcolor='#99CCCC'><strong>Numero</strong></td>
      <td width='24%' bgcolor='#99CCCC'><strong>Nom</strong></td>
      <td width='14%' bgcolor='#99CCCC'><strong>Categorie</strong></td>
      <td width='13%' bgcolor='#99CCCC'><strong>Prix</strong></td>
	  <td width='13%' bgcolor='#99CCCC'><strong>Ajouter Par</strong></td>
      <td width='12%' bgcolor='#99CCCC'><strong>Ajouter en</strong></td>
      <td width='9%' 
	  bgcolor='#99CCCC'><strong>Modifier</strong></td>
      <td width='9%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$product_list.= " <tr>
      <td  >$id</td>
      <td  >$product_name</td>
      <td  >$category</td>
      <td  >$price DA</td>
	  <td  >$AjouterPar</td>
      <td  >$date_added</td>
      <td  align='center' > <a href='inventory_edit_admin.php?pid=$id'><img src='../images/simple_btn/prod_edit.png' width='22' height='21' /></a> </td>
      <td  align='center' > <a href='inventory_list_admin.php?deleteid=$id'><img src='../images/simple_btn/prod_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$product_list.="</table>";
}
else{
$product_list="le store est vide, svp Ajouter une article !!";
}

///////////////////////////////////////////////////////////

// parse le formulaire d'Ajoute une article
if(isset($_POST['product_name'])){
$product_name=mysql_real_escape_string($_POST['product_name']);
$price=mysql_real_escape_string($_POST['price']);
$category= mysql_real_escape_string($_POST['category']);
$subcategory= mysql_real_escape_string($_POST['subcategory']);
$details= mysql_real_escape_string($_POST['details']);

$sql0= mysql_query("select id from products where product_name='$product_name' LIMIT 1");

$productMatch = mysql_num_rows($sql0);
if($productMatch>0){
  echo 'Il ya une deplication dans Nome de article, <a href="inventory_list_admin.php"> Clique Ici</a>' ;   
  exit();
}

$heure_ajoute =date("H:i:s");

$sql1=mysql_query("insert into products(product_name,price,details,category,subcategory,date_added,heure_ajoute,userID) VALUES ('$product_name','$price','$details','$category','$subcategory',now(),'$heure_ajoute','$idadmin')") or die(mysql_error());

$pid=mysql_insert_id();

$newname="$pid.jpg";
move_uploaded_file($_FILES['fileField']['tmp_name'], "../inventory_images/$newname");
header("location:inventory_list_admin.php");
exit(); 
}

?>

<?php
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
//  question de admin pour suppremer article
if(isset($_GET['deleteid'])){
echo 'est ce que sure de suppression larticle N:'.$_GET['deleteid'].'?   <a href="inventory_list_admin.php?yesdelete='.$_GET['deleteid'].'">OUI</a> | <a href="inventory_list_admin.php">NON</a> ';
exit();
}
// la suppression de article et leur image a partire le system 
if(isset($_GET['yesdelete'])){
$id_to_delete=$_GET['yesdelete'];
$sql=mysql_query("DELETE FROM products WHERE id='$id_to_delete' LIMIT 1")or die(mysql_error) ;

$pictodelete=("../inventory_images/$id_to_delete.jpg");
if(file_exists($pictodelete)){
unlink($pictodelete);
}
header("location:inventory_list_admin.php");
exit(); 
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256" />
<title>Gestion des article : Ajouter,Modif,Supp</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />
<script>
function showCat(str)
{
if (str=="")
  {
  document.getElementById("subcatHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==3 && xmlhttp.status==200)
    {
    document.getElementById("subcatHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","inventory_list_admin.php?q="+str,true);
xmlhttp.send();
}
</script>

</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
<div id="pageContent">
		<div id="pageContent">
		<div id="rech_user_div" align="right">
        <form action="#" method="POST">
			<?php echo $time_now.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';?>
       		<a href="inventory_list.php#inventoryForm"> + Ajouter Article</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 
   </div>


<div align="left" style="margin-left:35px" >
    <br/>
    <strong>Bienvenue &nbsp;" <?php echo $username ?>&nbsp;"&nbsp;dans gestion de L'article, Est que tu voller supprimer, modifier ou Ajouter une nouvelle articles ?</strong><br/>
  </div>
<div style="margin-left: 24px" align="left">
  <h3><strong>&nbsp;&nbsp;&nbsp;Votre Liste Des Articles:</strong></h3>
  <p>
  <?php echo  $tableAtt; ?>
  <?php echo $product_list; ?>	  </p>
  <p>&nbsp;</p>
  <hr />
  
</div>
<a name="inventoryForm"  id="inventoryForm"></a >
<h2 class="Style1">
  Ajouter Nouveaux Articles    </h2>
<form id="templatemo_search" name="myform" method="post" action="inventory_list_admin.php" enctype="multipart/form-data">
<table width="100%" border="0">
<tr>
<td width="237"><div align="right">Nom:&nbsp;&nbsp;&nbsp;</div></td>
<td width="739"><input name="product_name"  type="text" size="50"/></td>
</tr>
<tr>
<td><div align="right">Prix:&nbsp;&nbsp;&nbsp;</div></td>
<td> <input name="price" type="text" size="20"  /> DA</td>
</tr>
<tr>
<td><div align="right">Category:&nbsp;&nbsp;&nbsp;</div></td>
<td><select name="category"  id="category"size="1" onchange="showCat(this.value)"> 
 <option value="" selected="selected"></option>
<?php 
		  $sql_cat=mysql_query("SELECT * from categorie" )or die(mysql_error) ;
		  while($res = mysql_fetch_array($sql_cat)){
			  $cat_name=$res['cat_name'];
			  $id_categorie=$res['id_categorie'];
		  ?>
<option value="<?php echo  $id_categorie ?>"><?php echo $cat_name ?></option>
 <?php }?> 
 </select>
  </tr>
<tr>
<td><div align="right">Case de l'article:&nbsp;&nbsp;&nbsp; </div></td>
<td>

<select name="subcategory"     id="subcatHint">
  <option value="" selected="selected"  ></option>
  <?php 
  			$q=$_GET["q"];
		  $sql_subcat=mysql_query("SELECT * from subcategorie where id_category='$q' " )or die(mysql_error) ;
		  while($res2 = mysql_fetch_array($sql_subcat)){
			  $subcat_name=$res2['subcat_name'];
			  $id_subcategory=$res2['id_subcategory'];
		  ?>
 <option  value="<?php echo $id_subcategory ?>"><?php echo $subcat_name ?></option>
<?php }?>
</select></td>
</tr>
<tr>
<td><div align="right">Detailes:&nbsp;&nbsp;&nbsp;</div></td>
<td><textarea name="details" cols="70" rows="7"></textarea></td>
</tr>
<tr>
<td><div align="right">Image:&nbsp;&nbsp;&nbsp;</div></td>
<td><input name="fileField" type="file" class="Style1" size="50" /></td>
</tr>
<tr>
<td><div align="right"></div></td>
<td><p><br>
  <input name="Submit" type="submit" class="Style1"   value="Ajouter a Store" />
  <input name="button" type="reset" class="Style1" id="button" value="Mettre a zero" />
</p>
  <p>&nbsp;</p>
  <p>&nbsp; </p>  </tr>
</table>
</form>
</div>
<?php  include_once("../template_footer.php");?>
</div>
</div>
</body>
</html>
