<?php 
include"../storescripts/connect_to_mysql.php";

$username = "";
$email    = "";
$question = "";
$err_perd = "";
if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["question"])){
  $username  = mysql_real_escape_string($_POST["username"]);
  $email     = mysql_real_escape_string($_POST["email"]);
  $question  = mysql_real_escape_string($_POST["question"]);

  $sql_user   = mysql_query("select * from admin where username='$username' ");
  $count_user = mysql_num_rows($sql_user);
  if($count_user==0){
	  $err_perd.="Username n'existe pas !!<br />";
	  }
  $sql_email   = mysql_query("select * from admin where email='$email' ");
  $count_email = mysql_num_rows($sql_email);
  if($count_email==0){
	  $err_perd.="E-Mail n'existe pas !!<br />";
	  }
  $sql_question   = mysql_query("select * from admin where question='$question' ");
  $count_question = mysql_num_rows($sql_question);
  if($count_question==0){
	  $err_perd.="Reponse de securit� n'existe pas !!<br />";
	  }

    $sql_all   = mysql_query("select * from admin where username='$username' and email='$email' and question='$question' ");
    $count_all = mysql_num_rows($sql_all);
    if($count_all==0){
	    $err_perd.="<br />Les 3 Entre ne correspondent pas entre Elle !!<br />";
	    }
	else{
		$row_all  = mysql_fetch_array($sql_all);
		$password = $row_all['password'];
		$us = $row_all['username'];
		
mail("$email", " Toyour Store - Oublie de mot de passe" , "Bonjour, <strong>".$us."<strong/> Voici votre  mot de passe : <strong>".$password."</strong> ", "<br/>From: Lamouriml@hotmail.com");
 $err_perd.="Merci, Un E-mail vous a �t� envoy� avec votre mot de passe<br />";
		}
  	

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mot de passe est Perdu </title>

<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />
</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
    <div id="templatemo_login" style="margin-left: 24px" align="center">
      <p><br/>
      <div  style='background:#FFCCCC; border:solid 1px #FF3300;margin-left:300px;margin-right:300px; '>
      <font color="#000" size="+1"><?php echo $err_perd?></font>
      </div>
      
        <br/>
        <font size="+2" color="#FF6600"><strong>Mot de passe perdu</strong></font><br/><br/>
      <font size="4"><strong>Entrer le Pseudo et le Email:</strong></font></p>
     
      <font color="#FF3300"></font>
     
      <form  name="form1" method="post" action="perdu.php"  id="templatemo_search"><br/>
        <strong> Pseudo :</strong><br>
		<input name="username" type="text" size="40" id="username"  class="txt_field"  value="<?php echo $username ?>" />
        
        
        <br>
        <strong>Email :</strong><br>
		<input name="email" type="text" size="40"  id="email" class="txt_field" value="<?php echo $email ?>"/></p><br>
		<strong>Reponse  de securit&eacute; :</strong><br>
		<input name="question" type="text" size="40"  id="question" class="txt_field" value="<?php echo $question ?>"/>
        <p>
          <input name="button" type="submit" value="Se connecter"  class="sub_btn" />
        </p>
      </form>
      <br/><br/><br/>
    </div>
    
  </div></div>
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>