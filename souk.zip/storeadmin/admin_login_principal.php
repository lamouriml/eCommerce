<?php 
include"../storescripts/connect_to_mysql.php";

session_start(); 
if(isset($_SESSION["session"])){
header("location:indexAdmin.php");
exit();
}
if(isset($_GET['out']) ){
		session_unset();
		session_destroy();
		//$_log='<a  href="storeadmin/admin_login.php">LogIn  </a>&nbsp;&nbsp;';
		//$_insc='<a href="inscrit.php">Inscrit</a>&nbsp;&nbsp;&nbsp;';
		header("location:admin_login_principal.php");
	}
?>

<?php 
$err_log= "<img src='../images/simple_btn/key.png' width='32' height='32' />" ;
if(isset($_POST["username"]) && isset($_POST["password"])){
$manager  = mysql_real_escape_string($_POST["username"]);
$password = mysql_real_escape_string($_POST["password"]);
$sql      = mysql_query("SELECT * FROM admin WHERE username='$manager' and password='$password' and estAdmin='yes' LIMIT 1");

$existCount=mysql_num_rows($sql);
if($existCount==1){
  $row=mysql_fetch_array($sql);
	$id=$row["idadmin"];
  
	
	for ($ligne=0;$ligne<30;$ligne++)		//Cr�ation d'un identifiant al�atoire
		{
		$session.=substr('0123456789AZERTYUIOPMLKJHGFDSQWXCVBN',(rand()%(strlen('0123456789AZERTYUIOPMLKJHGFDSQWXCVBN'))),1);
		}
		mysql_query("UPDATE admin SET session='$session' WHERE password='$password'") or die ('Erreur : '.mysql_error());
		$_SESSION["session"]=$session;
	    header("location:indexAdmin.php");

  exit();
}else{
  $err_log= "<img src='../images/simple_btn/key_delete.png' width='32' height='32' /> <br><font color='red' size=4>information incorrect, ressayer autre fois</font> " ;
  
}
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SPECIALE POUR L'ADMINISTRATEUR</title>

<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />
</head>

<body>


<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>

  <div id="pageContent">
    <div id="templatemo_login" style="margin-left: 24px" align="center">
      <br><br>
      <font size="4"><strong>Entrer le Pseudo et le mot de pass pour la Login:<br>( SPECIALE POUR L'ADMINISTRATEUR )</strong></fonr><br><font color="#FF3300"><h3><?php echo $err_log ?></h3></font>
      
      <form  name="form1" method="post" action="admin_login_principal.php"  id="templatemo_search">
         Pseudo :<br>
		<input name="username" type="text" size="40" id="username"  class="txt_field"  />
        <br>Mot de pass :<br>
		<input name="password" type="password" size="40"  id="password" class="txt_field"/></p>
        <br>
        <p>
          <input name="button" type="submit" value="Se connecter"  id="button" class="sub_btn" />
        </p>
      </form>
     <br />
      
      <br />
    </div>
   <br /><br />
  </div>
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
