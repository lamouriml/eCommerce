<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php"; 
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}
//---------

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}

 ?>

<?php
// scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1'); 
?>

<?php 
$msg_err_3_pass=" ";
$msg_err_confi=" ";
$msg_err_pass_act=" ";
	
if(isset($_GET['uid'])){ 
	$targetID=$_GET['uid'];

	$sql=mysql_query("SELECT * FROM admin WHERE idadmin='$idadmin' ");
	$row=mysql_fetch_array($sql);
	$_pass1=$row["password"];
  	
if(isset($_POST['modif'])){
	$pass10=mysql_real_escape_string($_POST['pass1']);
	$pass20=mysql_real_escape_string($_POST['pass2']);
	$pass30=mysql_real_escape_string($_POST['pass3']);
	$uid=mysql_real_escape_string($_POST['thisID']);

  if( isset($pass10) && isset($pass20) && isset($pass30) ){
	  if($pass10!='' && $pass30!='' && $pass30!=''  ){
	  if($_pass1==$pass10){
		 if($pass20==$pass30){	
			$sql0= mysql_query("UPDATE admin SET password='$pass20' WHERE idAdmin='$uid' LIMIT 1");
 			echo "Votre mot de pass a �t� Modifier , Merci ... <a href='index.php'>Votre Profile</a>";
 			exit(); 
		 }
		 else{
			 $msg_err_confi= "  il ya une ereure dans la confirmation de mot de pass";
			 }
	  }
	  else{
		  $msg_err_pass_act= "  le mot de pass actuelle est incorrect !!";
		  }
  }
  else{
	  $msg_err_3_pass= "   svp saisser tout les mot de pass !! ";
	  }
 
}
 ////////////////
 
 
 ////////////////
}
}
?>
 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Modification de mon Login information</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
    <div id="rech_user_div" align="right">
        <form action="user_edit_login.php" method="POST">
        	
            <a  href="index.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 
    
    
    
    <a name="inventoryForm"  id="inventoryForm"></a >
	<h2 class="Style1">
	  Modifier votre Mot de passe</h2>
      Confirmer bien le cas des lettres soit majuscule ou muniscule
      <br/>Pour anuller Reteur a la page de gestion<br/><br/>
            
    <form id="myform" name="myform" method="post" action="user_edit_login.php?uid=<?php echo $targetID?>" enctype="multipart/form-data">
      <table width="100%" border="0">

<tr>
  <td><div align="right">
    <div align="right"></div>
  </div></td>
  <td><em><font color="#FF0000"><?php echo $msg_err_3_pass ?></font></em>&nbsp;</td>
</tr>
<tr>
  <td class="Style1"><div align="right"><strong>Mot  pass Actuele:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="pass1" type="text" class="iscritfield"  size="50" maxlength="50"/></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><em><font color="#FF0000"><?php echo $msg_err_pass_act ?>&nbsp;</font></em></td>
</tr>
<tr>
  <td><div align="right"><strong>nouveau mot pass:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="pass2" type="text" class="iscritfield"   size="50" maxlength="30"/></td>
</tr>
<tr>
  <td><div align="right"><strong>Confirmer nouveau mot pass:&nbsp;&nbsp;&nbsp;</strong></div></td>
  <td><input name="pass3" type="text" class="iscritfield"   size="50" maxlength="30"/></td>
</tr>
<tr>
  <td>&nbsp; </td>
  <td><em><font color="#FF0000"><?php echo $msg_err_confi ?>&nbsp;</font></em></td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td>&nbsp;</td>
</tr>
<tr>
  <td>&nbsp;</td>
  <td><p><br>
    <input name="thisID" type="hidden" value="<?php echo $targetID ?>" />
    <input type="submit"  name="modif" value="Applique" />
</p></tr>
</table>
    </form><br/><br/><br/><br/>


  </div>
  </div>
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
