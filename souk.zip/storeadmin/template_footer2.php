
<div class="Style1" id="pageFooter" align="center" style=" font-size:10px">
<a href="admin_login.php">LOGIN</a>
&nbsp;|&nbsp;
<a href="../inscrit.php">INSCRIT</a>
 
 <BR>
     <a href="../index.php">ACCEUIL</a> |
     <a href="../LesArticles.php">ARTICLES</a> |
     <a href="../apropos.php">A PROPOS</a> |
     <a href="../contact.php">CONTACT</a> |
     <a href="../news.php">JOURNALE</a> | 
     <a href="#">FORUM</a>
     <BR>
        Designe By LAMOURI ML 2013&nbsp;&reg; &nbsp;|&nbsp;<a href="admin_login_principal.php">Admin</a>
</div>