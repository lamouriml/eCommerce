<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
?>
<?php /////////////////////////////////////////////////////

// l'affichge DE Dettaille de user
if(isset($_GET['uid'])){
    $targetID=$_GET['uid'];
	$sql1=mysql_query("SELECT * FROM admin WHERE idAdmin='$targetID' LIMIT 1");
	$userCount=mysql_num_rows($sql1);
    $row=mysql_fetch_array($sql1);
	if($userCount>0){
   		    
			$_username=$row["username"];
	   		$_password=$row["password"];
	  		$_nom=$row["nom"];
	  		$_prenom=$row["prenom"];
			$_email=$row["email"];
			$_tel=$row["tel"];
			$_pays=$row["pays"];
	   		$_adresse=$row["adresse"];
			$_estAdmin=$row["estAdmin"];
			$_question=$row["question"];
			$_DateInscrit=strftime("%d %b %Y",strtotime($row["last_log_date"]));
	}
	else{
		echo 'Detaille user not exist ,merci !! ';
	    exit();
	}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>les Detaille des UT</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
<div id="pageContent">
	<div id="rech_user_div" align="right">
        <form action="#" method="POST">
        	<a  href="user_list_admin.php">Liste  </a>&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=" "  id="search_txt" />  
     </form>
     </div> 

<div align="left" style="margin-left:35px" >
  <br />
  <p><strong>Les Information de l'utilisateur : <?php echo $_nom?>&nbsp;<?php echo $_prenom ?></strong></p>
</div>
<div style="margin-left: 100px" align="left">
  <h3>&nbsp;</h3>
  <table width="600" border="0" cellpadding="10" cellspacing="5">
    <tr >
      <td width="34%"  align="right"><em>Id De UT:&nbsp; </em></td>
      <td width="66%"><strong>&nbsp;&nbsp;&nbsp;<?php echo  $targetID ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Username:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_username ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Password:  &nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_password ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Reponse Securit�:  &nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_question ?></strong></td>
    </tr>
    <tr>
      <td colspan="2"  align="center">------------------------------------------------------------------------------------</td>
      </tr>
    <tr>
      <td  align="right"><em>Nom:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_nom ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Prenom:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_prenom ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>E-Mail:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_email ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Paye:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_pays ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Adresse:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_adresse ?></strong></td>
    </tr>
    <tr>
      <td  align="right"><em>Telephone:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_tel ?></strong></td>
    </tr>
    <tr>
      <td colspan="2"  align="center">----------------------------------------------------------------------------------</td>
      </tr>
    <tr>
      <td  align="right"><em>Date de Inscription:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_DateInscrit ?></strong></td>
    </tr>
    <tr>
      <td align="right"><em>Est Admin ?:&nbsp;</em></td>
      <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $_estAdmin ?></strong></td>
    </tr>
  </table>
  
  
<br /><br />  
</div></div>
<?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
