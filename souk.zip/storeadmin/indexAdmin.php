<?php
// scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
 
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>&#1575;&#1606;&#1575; <?php echo $manager; ?> &#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1605;&#1608;&#1602;&#1593;</title>
<link href="../favicon.ico" rel="shortcut icon" />
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
</head>

<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
  		 <div id="rech_user_div" align="right">
      		<form action="#" method="POST">
        		<a  href="index.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            	<a  href="../index.php?out">Deconnexion  </a>          
   			  <input name="Search" type="submit" value="Search"  id="search_btn"   />
    	      <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
   	  		</form>
        </div> 
   
<div align="left">      
<div id="template_menu_header" ><font size="4" color="#FFFFFF "><strong>&nbsp;&nbsp;&nbsp;La Gestion Du :</strong></font>	</div>        
<div id="templatemo_menu" >
       <ul>
              <li><a href="inventory_list_admin.php"><strong>Articles </strong></a>
              </li>
              <li><a href="#"><strong>Categories </strong></a>
              </li>
              <li><a href="user_list_admin.php"><strong>Utilisateures</strong></a>
              </li>
              <li><a href="news_list_admin.php"><strong>Journales</strong></a>
              </li>
              <li><a href="messages_list_admin.php"><strong>Messages</strong></a>
              </li>
              <li><a href="contact_list_admin.php"><strong>Contacts</strong></a>
              </li>
              
              <li><a href="contact_list_admin.php"><strong>Telechargement</strong></a>
              </li>
              
              <li><a href="contact_list_admin.php"><strong>Couleur & Th�me</strong></a>
              </li>
       </ul>       
  </div> </div> 
  
<font size="4"><strong> Bienvenue &nbsp;<font color="#FF6600"><?php echo $username ?></font>&nbsp;dans gestion de site :</strong></font>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	
<br/><br/><br/><br/>
  </div>
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
