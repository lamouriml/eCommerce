<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";   
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $iad=$row["idadmin"];
  $u=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
/////////////////////////////////////////////////////

// l'affichge des user
$user_list="";
 $tableAtt="";
$sql=mysql_query("select * from admin ORDER BY idadmin ASC");
$userCount=mysql_num_rows($sql);

if($userCount>0){
while($row=mysql_fetch_array($sql)){
  $idadmin=$row["idadmin"];
  $username=$row["username"];
  $nom=$row["nom"];
  $prenom=$row["prenom"];
  $estAdmin=$row["estAdmin"];

  $tableAtt="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='2' cellpadding='0'  >
    <tr>
      <td width='9%'  bgcolor='#99CCCC'><strong>ID</strong></td>
      <td width='24%' bgcolor='#99CCCC'><strong>Username</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Nom</strong></td>
      <td width='21%' bgcolor='#99CCCC'><strong>Prenom</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Admin ?</strong></td>
	  <td width='10%' bgcolor='#99CCCC'><strong>Detaille</strong></td>
      <td width='9%' bgcolor='#99CCCC'><strong>Modifier</strong></td>
      <td width='9%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$user_list.= " <tr>
      <td  >$idadmin</td>
      <td  >$username</td>
      <td  >$nom</td>
      <td  >$prenom</td>
      <td  >$estAdmin</td>
	   <td  align='center'> <a href='user_details_admin.php?uid=$idadmin'><img src='../images/simple_btn/user.png' width='22' height='21' /></a> </td>
      <td  align='center'> <a href='user_edit_admin.php?uid=$idadmin'><img src='../images/simple_btn/user_edit.png' width='22' height='21' /></a> </td>
      <td  align='center' > <a href='user_list_admin.php?deleteid=$idadmin'><img src='../images/simple_btn/user_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$user_list.="</table>";
}
else{
$user_list="liste des users vide !!";
}
?>
<?php 
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
//  question de admin pour suppremer user
if(isset($_GET['deleteid'])){
echo 'est ce que sure de suppression le Utilisateur N:'.$_GET['deleteid'].'?   <a href="user_list_admin.php?yesdelete='.$_GET['deleteid'].'">OUI</a> | <a href="user_list_admin.php">NON</a> ';
exit();
}
// la suppression de user  a partire le system 
if(isset($_GET['yesdelete'])){
$id_to_delete=$_GET['yesdelete'];
$sql=mysql_query("DELETE FROM admin WHERE idAdmin='$id_to_delete' LIMIT 1")or die(mysql_error) ;
header("location:user_list_admin.php");
exit(); 
}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Gestion de UT</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header2.php");?>
<div id="pageContent">
	<div id="rech_user_div" align="right">
		<form action="#" method="POST">
       		<a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 

<div align="left" style="margin-left:35px" ><br/>
  <p><strong>Bienvenue &nbsp;" &nbsp;<?php echo $u ?>&nbsp; "&nbsp;dans gestion de L'Utilisateure, Est que tu voller supprimer, modifier une Utilisateure ?</strong>
  </p>
  <br/><br/>
</div>
<div style="margin-left: 24px" align="left">
  <h3><strong>Liste Des Utilisateure:</strong></h3>
  <?php echo  $tableAtt; ?>
  <?php echo $user_list; ?>
  <br/><br/><br/>
</div>
</div>
</div>
<?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
