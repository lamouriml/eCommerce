<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";
?>
<?php 
 
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
?>
<?php /////////////////////////////////////////////////////
$contCount2="";
$sql2=mysql_query("select * from contact WHERE cont_est_vue='no' ORDER BY cont_date ASC");
$contCount2=mysql_num_rows($sql2);

// l'affichge DE Dettaille de user

$est="yes";
if(isset($_GET['cid'])){
    $targetID=$_GET['cid'];
	$sql1=mysql_query("SELECT * FROM contact WHERE cont_id='$targetID' LIMIT 1");
	$contCount=mysql_num_rows($sql1);
    $row=mysql_fetch_array($sql1);
	if($contCount>0){
   		    
		  $cont_id=$row["cont_id"];
  		  $cont_nom=$row["cont_nom"];
		  $cont_email=$row["cont_email"];
		  $cont_tel=$row["cont_tel"];
 	  	  $cont_titre=$row["cont_titre"];
 		  $estVue=$row["cont_est_vue"];
		  $cont_contenu=$row["cont_contenu"];
		  $cont_date=strftime("%d %b %Y",strtotime($row["cont_date"]));
	}
	else{
		echo 'contact not exist ,merci !! ';
	    exit();
	}
	$sql3=mysql_query("UPDATE contact SET cont_est_vue='$est' WHERE cont_id='$targetID'  ");
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>les Detaille des UT</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
<div id="pageContent">
	<div id="rech_user_div" align="right">
        <form action="#" method="POST">
            <a  href="contact_list_admin.php">Contact(<strong><?php echo $contCount2; ?></strong>)  </a>&nbsp;&nbsp;&nbsp;
        	<a  href="contact_list_admin.php">Liste  </a>&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=" "  id="search_txt" />  
     </form>
     </div> 
<br/> 

<div style="margin-left: 100px" align="left">
  
  <table width="100%" border="0" cellpadding="10" cellspacing="10">
    <tr>
      <td width="34%"  align="left"><div id='cont_Div2' >
  <strong><img src="../images/simple_btn/msg_open.png" width="32" height="32" /> <br/>Le message de contact numero : <?php echo "0".$cont_id?>&nbsp;</strong>
</div></td>
      <td width="66%"><strong>&nbsp;</strong>
        </td>
    </tr>
    <tr>
      <td  align="left"><div id='cont_Div2' >
        <br/>
        <strong><em>&nbsp;&nbsp;&nbsp;</em></strong><em>Par :</em><strong> &nbsp;&nbsp;<?php echo $cont_nom ?></strong>
        <strong><em><br/>
        &nbsp;&nbsp;</em></strong><em>&nbsp;Tel :&nbsp;</em><strong><em>&nbsp;</em><?php echo $cont_tel ?></strong>
        <strong><em><br/>
        &nbsp;&nbsp;&nbsp;</em></strong><em>Email :  </em><strong><em>&nbsp;&nbsp;</em><?php echo $cont_email ?></strong><br/>
        &nbsp;&nbsp;&nbsp;<em>Date d'envoi :&nbsp;</em><strong><em>&nbsp; <?php echo $cont_date ?></em></strong><br/>
        <br/>
        
      </div></td>
      <td align="center">&nbsp;</td>
    </tr>
    <tr>
      <td  align="right">&nbsp;</td>
      <td align="center"><div id='cont_Div'><strong>&nbsp;&nbsp;&nbsp;Titre :&nbsp;&nbsp;<?php echo $cont_titre ?></strong></div></td>
    </tr>
    <tr align="justify">
      <td  align="left"><br/><br/></td>
      <td align="center"><div id="cont_Div"><br/><br/><strong><?php echo $cont_contenu ?></strong><br/><br/></div>
        <p><strong>&nbsp;&nbsp;&nbsp;</strong></p>
        <p>&nbsp;</p></td>
    </tr>
  </table>
  
  
<br /><br />  
</div></div>
<?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
