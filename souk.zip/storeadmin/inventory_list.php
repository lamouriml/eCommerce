<?php 
include"../storescripts/connect_to_mysql.php"; 
error_reporting(E_ALL);
ini_set('display_errors','1');  ?>

<?php 
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}
//---------

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}

/////////////////////////////////////////////////////

// l'ffichge des article
$product_list="";
$sql=mysql_query("select * from products where userID='$idadmin' ORDER BY date_added DESC") or die (mysql_error);
$productCount=mysql_num_rows($sql);

if($productCount>0){
while($row=mysql_fetch_array($sql)){
  $id=$row["id"];
  $category=$row["category"];
  $price=$row["price"];
  $product_name=$row["product_name"];
  $date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
  $tableAtt="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='2' cellpadding='0'  >
    <tr>
      <td width='9%'  bgcolor='#99CCCC'><strong>Numero</strong></td>
      <td width='24%' bgcolor='#99CCCC'><strong>Nom</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Categorie</strong></td>
      <td width='13%' bgcolor='#99CCCC'><strong>Prix</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Ajouter en</strong></td>
      <td width='9%' bgcolor='#99CCCC'><strong>Modifier</strong></td>
      <td width='9%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$product_list.= " <tr>
      <td  >$id</td>
      <td  >$product_name</td>
      <td  >$category</td>
      <td  >$price DA</td>
      <td  >$date_added</td>
      <td  align='center'> <a href='inventory_edit.php?pid=$id'><img src='../images/simple_btn/prod_edit.png' width='22' height='21' /></a> </td>
      <td  align='center' > <a href='inventory_list.php?deleteid=$id'><img src='../images/simple_btn/prod_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$product_list.="</table>";
}
else{
$product_list="votre store est vide, svp Ajouter une article !!";
}
///////////////////////////////////////////////////////////
// parse le formulaire d'Ajoute une article
if(isset($_POST['product_name'])){
$product_name=mysql_real_escape_string($_POST['product_name']);
$price=mysql_real_escape_string($_POST['price']);
$category= mysql_real_escape_string($_POST['category']);
$subcategory= mysql_real_escape_string($_POST['subcategory']);
$details= mysql_real_escape_string($_POST['details']);
$case_art= mysql_real_escape_string($_POST['case']);


$sql0= mysql_query("select id from products where product_name='$product_name' ") or die (mysql_error);

$productMatch = mysql_num_rows($sql0);
if($productMatch>0){
  echo 'Il ya une deplication dans Nome de article, <a href="inventory_list.php"> Clique Ici</a>' ;   
  exit();
}
$heure_ajoute =date("H:i:s");
$sql1=mysql_query("insert into products(product_name,price,details,category,subcategory,date_added,heure_ajoute,userID,product_case) VALUES ('$product_name','$price','$details','$category','$subcategory',now(),'$heure_ajoute','$idadmin','$case_art' )") or die(mysql_error());

$pid=mysql_insert_id();

$newname="$pid.jpg";
move_uploaded_file($_FILES['fileField']['tmp_name'], "../inventory_images/$newname");
header("location:inventory_list.php");
exit(); 
}

?>

<?php
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
//  question de admin pour suppremer article
if(isset($_GET['deleteid'])){
echo 'est ce que sure de suppression larticle N:'.$_GET['deleteid'].'?   <a href="inventory_list.php?yesdelete='.$_GET['deleteid'].'">OUI</a> | <a href="inventory_list.php">NON</a> ';
exit();
}
// la suppression de article et leur image a partire le system 
if(isset($_GET['yesdelete'])){
$id_to_delete=$_GET['yesdelete'];
$sql=mysql_query("DELETE FROM products WHERE id='$id_to_delete' LIMIT 1") or die(mysql_error) ;

$pictodelete=("../inventory_images/$id_to_delete.jpg");
if(file_exists($pictodelete)){
unlink($pictodelete);
}
header("location:inventory_list.php");
exit(); 
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Gestion des article : Ajouter,Modif,Supp</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />
<script>
function showCat(str)
{
if (str=="")
  {
  document.getElementById("subcatHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==3 && xmlhttp.status==200)
    {
    document.getElementById("subcatHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","inventory_list.php?q="+str,true);
xmlhttp.send();
}
</script>
<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>

<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
<div id="pageContent">
		<div id="rech_user_div" align="right">
        <form action="#" method="POST">
       		<a href="inventory_list.php#inventoryForm"> + Ajouter Article</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a  href="index.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 


<div align="left" style="margin-left:35px" >
  
  <br/>

  <br/><strong>Bienvenue &nbsp; <font color="#003366"><?php echo $username ?></font>&nbsp;&nbsp;dans gestion de L'article, Est que tu voller supprimer, modifier ou Ajouter une nouvelle articles ?</strong>
  <br/><br/>
  
</div>
<div style="margin-left: 24px" align="left">
  <h3><strong>&nbsp;&nbsp;&nbsp;Votre Liste Des Articles:</strong></h3>
  <p>
  <?php echo  $tableAtt; ?>
  <?php echo $product_list; ?>	  </p>
  <p>&nbsp;</p>
  <hr />
  
</div>
<a name="inventoryForm"  id="inventoryForm"></a >
<h2 class="Style1">
  Ajouter Nouveaux Articles    </h2>
<form id="templatemo_search" name="myform" method="post" action="inventory_list.php" enctype="multipart/form-data">
<table width="100%" border="0">
 <tr>
    <td><div align="right">Cas de L'article:</div></td>
    <td>&nbsp;
    <font color="#00CC00">Disponible</font><input name="case" type="radio" value="Disponible" checked="checked" />&nbsp;&nbsp;&nbsp;
    <font color="#FF9933">Limmiter</font><input name="case" type="radio" value="Limmiter" />&nbsp;&nbsp;&nbsp;
   
    </td>
  </tr>

<tr>
<td width="237"><div align="right">Nom:&nbsp;&nbsp;&nbsp;</div></td>
<td width="739"><input name="product_name"  type="text" size="50"/></td>
</tr>
<tr>
<td><div align="right">Prix:&nbsp;&nbsp;&nbsp;</div></td>
<td> <input name="price" type="text" size="20"  /> DA</td>
</tr>
<tr>
<td><div align="right">Categorrie:&nbsp;&nbsp;&nbsp;</div></td>
<td><select name="category"  id="category"size="1" onchange="showCat(this.value)">
    <option value="">&nbsp;</option>
  <?php 
		  $sql_cat=mysql_query("SELECT * from categorie" )or die(mysql_error) ;
		  while($res_cat = mysql_fetch_array($sql_cat)){
			  $cat_name=$res_cat['cat_name'];
			  $id_categorie=$res_cat['id_categorie'];
		  ?>
<option value="<?php echo  $id_categorie ?>"><?php echo $cat_name ?></option>
 <?php }?>
    </select></td>
</tr>
<tr>
<td><div align="right">Sous Categorie:&nbsp;&nbsp;&nbsp; </div></td>
<td>
    <select name="subcategory"   id="subcatHint" size="1">
	  <option value="" selected="selected">&nbsp;</option>
	  <?php 
  			$q=$_GET["q"];
		  $sql_subcat=mysql_query("SELECT * from subcategorie where id_category='$q' " )or die(mysql_error) ;
		  while($res_subcat = mysql_fetch_array($sql_subcat)){
			  $subcat_name=$res_subcat['subcat_name'];
			  $id_subcategory=$res_subcat['id_subcategory'];
		  ?>
 <option  value="<?php echo $id_subcategory ?>"><?php echo $subcat_name ?></option>
<?php }?>
</select></td>
</tr>
<tr>
<td><div align="right">Detailes:&nbsp;&nbsp;&nbsp;</div></td>
<td><textarea name="details" cols="50" rows="7"></textarea></td>
</tr>
<tr>
<td><div align="right">Image:&nbsp;&nbsp;&nbsp;</div></td>
<td><input name="fileField" type="file" class="Style1" size="50" /></td>
</tr>
<tr>
<td><div align="right"></div></td>
<td><br><br>
  <input name="Submit" type="submit" class="Style1"   value="Ajouter a Store" />
  <input name="button" type="reset" class="Style1" id="button" value="Mettre a zero" />
<br>
    </tr>
</table>
</form>
<br><br><br><br><br><br>
</div>

<?php  include_once("template_footer2.php");?>
</div></div>
</body>
</html>
