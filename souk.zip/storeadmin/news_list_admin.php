<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";   
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
/////////////////////////////////////////////////////

// l'affichge des article
$news_list="";
$sql=mysql_query("select * from news ORDER BY dateAjoute DESC");
$userCount=mysql_num_rows($sql);

if($userCount>0){
while($row=mysql_fetch_array($sql)){
  $idNews=$row["idNews"];
  $titre=$row["titre"];
  $resume=$row["resume"];
  $tout=$row["tout"];
  $dateAjoute=strftime("%d %b %Y",strtotime($row["dateAjoute"]));

  $tableAtt="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='2' cellpadding='0'  >
    <tr>
      <td width='10%'  bgcolor='#99CCCC'><strong>IdNews</strong></td>
      <td width='40%' bgcolor='#99CCCC'><strong>Titre</strong></td>
      <td width='8%' bgcolor='#99CCCC'><strong>Ajouter en</strong></td>
      <td width='6%' bgcolor='#99CCCC'><strong>Modifier</strong></td>
      <td width='6%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$news_list.= " <tr>
      <td  >$idNews</td>
      <td  >$titre</td>
      <td  >$dateAjoute</td>
      <td   align='center'> <a href='news_edit_admin.php?nid=$idNews'><img src='../images/simple_btn/note_edit.png' width='22' height='21' /></a> </td>
      <td   align='center'> <a href='news_list_admin.php?deleteid=$idNews'><img src='../images/simple_btn/note_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$news_list.="</table>";
}
else{
$news_list=" svp Ajouter une news !!";
}

///////////////////////////////////////////////////////////

// parse le formulaire d'Ajoute une News
if(isset($_POST['titre'])){
$titre=mysql_real_escape_string($_POST['titre']);
$resume=mysql_real_escape_string($_POST['resume']);
$tout= mysql_real_escape_string($_POST['tout']);


$sql0= mysql_query("select idNews from news where titre='$titre' LIMIT 1");

$newstMatch = mysql_num_rows($sql0);
if($newsMatch>0){
  echo 'Il ya une deplication dans Titre, <a href="news_list_admin.php"> Clique Ici</a>' ;   
  exit();
}

$sql1=mysql_query("insert into news(titre,resume,tout,dateAjoute) VALUES ('$titre','$resume','$tout',now())") or die(mysql_error());

$nid=mysql_insert_id();

$newname="$nid.jpg";
move_uploaded_file($_FILES['fileField']['tmp_name'], "../news_images/$newname");
header("location:news_list_admin.php");
exit(); 
}

?>

<?php
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
//  question de admin pour suppremer news
if(isset($_GET['deleteid'])){
echo 'est ce que sure de suppression le News N:'.$_GET['deleteid'].'?   <a href="news_list_admin.php?yesdelete='.$_GET['deleteid'].'">OUI</a> | <a href="news_list_admin.php">NON</a> ';
exit();
}
// la suppression de news et leur image a partire le system 
if(isset($_GET['yesdelete'])){
$id_to_delete=$_GET['yesdelete'];
$sql=mysql_query("DELETE FROM news WHERE idNews='$id_to_delete' LIMIT 1")or die(mysql_error) ;

$pictodelete=("../news_images/$id_to_delete.jpg");
if(file_exists($pictodelete)){
unlink($pictodelete);
}
header("location:news_list_admin.php");
exit(); 
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>la gestion des journal ( Liste des journal)</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
<div id="pageContent">
<div id="rech_user_div" align="right">
        <form action="#" method="POST">
       		<a href="#inventoryForm"> + Ajouter Journal</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 


<div align="left" style="margin-left:35px" >
  <br/><br/><strong>Bienvenue &nbsp;" <?php echo $username ?>"&nbsp;dans gestions des Journales, Est que tu voller supprimer, modifier ou Ajouter une nouvelle Journale ?</strong>
  
  <br/><br/><br/>
</div>
<div style="margin-left: 24px" align="left">
  <h3><strong>Votre Liste Des Journales:</strong></h3>
  <p>
  <?php echo  $tableAtt; ?>
  <?php echo $news_list; ?>	  </p>
  <p>&nbsp;</p>
  <hr />
  
</div>
<a name="inventoryForm"  id="inventoryForm"></a >
<h2 class="Style1">
  Ajouter Nouveaux Journal    </h2>
<form id="templatemo_search" name="myform" method="post" action="news_list_admin.php" enctype="multipart/form-data">
<table width="100%" border="0">
<tr>
  <td width="237"><div align="right">Titre:&nbsp;&nbsp;&nbsp;</div></td>
  <td width="739"><input name="titre"  type="text" size="70"/></td>
</tr>
<tr>
  <td><div align="right">Resum&eacute;:&nbsp;&nbsp;&nbsp;</div></td>
  <td><textarea name="resume" cols="70" rows="5"></textarea></td>
</tr>
<tr>
  <td><div align="right">Description:&nbsp;&nbsp;&nbsp;</div></td>
  <td><textarea name="tout" cols="70" rows="15"></textarea></td>
</tr>
<tr>
<td><div align="right">Image:&nbsp;&nbsp;&nbsp;</div></td>
<td><input name="fileField" type="file" class="Style1" size="50" /></td>
</tr>
<tr>
<td><div align="right"></div></td>
<td><p><br>
  <input name="Submit" type="submit" class="Style1"   value="Ajouter a Store" />
  <input name="button" type="reset" class="Style1" id="button" value="Mettre a zero" />
</p>
  <p>&nbsp;</p>
  <p>&nbsp; </p>  </tr>
</table>
</form>
</div></div>
<?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
