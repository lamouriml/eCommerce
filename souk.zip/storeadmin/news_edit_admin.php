<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php"; 
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
 ?>

<?php // scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1');  ?>

<?php 
//  assurer que le fourmulaire est plin de information
if(isset($_GET['nid'])){
    $targetID=$_GET['nid'];
	$sql1=mysql_query("select * from news WHERE idNews='$targetID' LIMIT 1");
	$newsCount=mysql_num_rows($sql1);
	if($newsCount>0){
   		$row=mysql_fetch_array($sql1);
	  		$_titre=$row["titre"];
			$_resume=$row["resume"];
	   		$_tout=$row["tout"];
	}	
}
 
// parse le formulaire Modif une news
if(isset($_POST['Appliquer'])){
$nid = mysql_real_escape_string($_POST['thisID']);
$idNews = mysql_real_escape_string($_POST['idNews']);
$titre0 = mysql_real_escape_string($_POST['titre']);
$resume0 = mysql_real_escape_string($_POST['resume']);
$tout0 = mysql_real_escape_string($_POST['tout']);
$sql0 = mysql_query("UPDATE news SET titre='$titre0',resume='$resume0',tout='$tout0' WHERE idNews='$nid' LIMIT 1");

if($_FILES['fileField']['tmp_name']!=""){
 $newname="$nid.jpg";
 move_uploaded_file($_FILES['fileField']['tmp_name'], "../news_images/$newname");
} 
 header("location:news_list_admin.php");
 exit(); 

} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>News Edit</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
  <div id="rech_user_div" align="right">
        <form action="#" method="POST">
        	<a  href="news_list_admin.php">Liste  </a>&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 
  
  
    
    <div style="margin-left: 24px" align="left">
      <h4><strong>la modification de l'News correspondont N : <?php echo $targetID?></strong></h4>
    </div>
          <a name="inventoryForm"  id="inventoryForm"></a >
	<h2 class="Style1">
	  Modifier L'Article    </h2>
	<form id="templatemo_search" name="myform" method="post" action="news_edit_admin.php" enctype="multipart/form-data">
<table width="100%" border="0">
<tr>
  <td width="237"><div align="right">Titre:&nbsp;&nbsp;&nbsp;</div></td>
  <td width="739"><input name="titre"  type="text" size="70" value="<?php echo $_titre ?>"/></td>
</tr>
<tr>
  <td><div align="right">Resum&eacute;:&nbsp;&nbsp;&nbsp;</div></td>
  <td><textarea name="resume" cols="70" rows="5" ><?php echo $_resume ?></textarea></td>
</tr>
<tr>
  <td><div align="right">Description:&nbsp;&nbsp;&nbsp;</div></td>
  <td><textarea name="tout" cols="70" rows="15"><?php echo $_tout ?></textarea></td>
</tr>
<tr>
<td><div align="right">Image:&nbsp;&nbsp;&nbsp;</div></td>
<td><input name="fileField" type="file" class="Style1" size="50" /></td>
</tr>
<tr>
<td><div align="right"></div></td>
<td><br>
  <input name="thisID" type="hidden" value="<?php echo $targetID ?>" />	
  <input name="Appliquer" type="submit" class="Style1"   value="Appliquer" />
  <input name="modif" type="reset" class="Style1" id="button" value="Mettre a zero" />

  </tr>
</table>
</form>
<br /><br /><br />
</div>
  <?php  include_once("template_footer2.php");?>
</div>

</body>
</html>
