<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php";   
 
 
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login_principal.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
/////////////////////////////////////////////////////

//////////////////////////////////////// l'affichge des Contact non vue
$msg_list1="";
$tableAtt="";
$sql=mysql_query("select * from contact WHERE cont_est_vue='no' ORDER BY cont_date ASC");
$contCount1=mysql_num_rows($sql);

if($contCount1>0){
while($row=mysql_fetch_array($sql)){
  $cont_id=$row["cont_id"];
  $cont_nom=$row["cont_nom"];
  $cont_email=$row["cont_email"];
  $cont_tel=$row["cont_tel"];
  $cont_titre=$row["cont_titre"];
  $estVue=$row["cont_est_vue"];
  $cont_date=$row["cont_date"];
  $cont_id=$row["cont_id"];
  $cont_date=strftime("%d %b %Y",strtotime($row["cont_date"]));
 

  $tableAtt="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='2' cellpadding='0'  >
    <tr>
     
      <td width='24%' bgcolor='#99CCCC'><strong>Nom</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Email</strong></td>
      <td width='35%' bgcolor='#99CCCC'><strong>Titre</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>La Date</strong></td>
      <td width='15%' bgcolor='#99CCCC'><strong>Detaille</strong></td>
	  <td width='15%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$msg_list1.= " <tr>
      
      <td  >$cont_nom</td>
      <td  >$cont_email</td>
      <td  >$cont_titre</td>
      <td  >$cont_date</td>
	  <td  align='center'> <a href='contact_details_admin.php?cid=$cont_id'><img src='../images/simple_btn/msg.png' width='22' height='21' /></a> </td>
      <td  align='center'> <a href='contact_list_admin.php?deleteid=$cont_id'><img src='../images/simple_btn/msg_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$msg_list1.="</table>";
}
else{
$msg_list1="La liste est vide";
}


////////////////////////////////// l'affichge des Contact vue
$msg_list2="";
$tableAtt2="";
$sql2=mysql_query("select * from contact WHERE cont_est_vue='yes' ORDER BY cont_date ASC");
$contCount2=mysql_num_rows($sql2);

if($contCount2>0){
while($row2=mysql_fetch_array($sql2)){
  $cont_id2=$row2["cont_id"];
  $cont_nom2=$row2["cont_nom"];
  $cont_email2=$row2["cont_email"];
  $cont_tel2=$row2["cont_tel"];
  $cont_titre2=$row2["cont_titre"];
  $estVue2=$row2["cont_est_vue"];
  $cont_id2=$row2["cont_id"];
  $cont_date2=strftime("%d %b %Y",strtotime($row2["cont_date"]));
  

  $tableAtt2="
  <table  width='100%' border='4'  bordercolor='#111111'  cellspacing='0' cellpadding='0'  >
    <tr>
      
      <td width='24%' bgcolor='#99CCCC'><strong>Nom</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>Email</strong></td>
      <td width='30%' bgcolor='#99CCCC'><strong>Titre</strong></td>
      <td width='18%' bgcolor='#99CCCC'><strong>La Date</strong></td>
      <td width='20%' bgcolor='#99CCCC'><strong>Detaille</strong></td>
	  <td width='15%' bgcolor='#99CCCC'><strong>Supprimer</strong></td>
    </tr>";
$msg_list2.= " <tr>
      
      <td  >$cont_nom2</td>
      <td  >$cont_email2</td>
      <td  >$cont_titre2</td>
      <td  >$cont_date2</td>
	  
	  
	  <td   align='center'> <a href='contact_details_admin.php?cid=$cont_id2'><img src='../images/simple_btn/msg_open.png' width='22' height='21' /></a> </td>
      <td  align='center'> <a href='contact_list_admin.php?deleteid=$cont_id2'><img src='../images/simple_btn/msg_delete.png' width='22' height='21' /></a> </td>
    </tr>
  ";
}
$msg_list2.="</table>";
}
else{
$msg_list2="La liste est vide !!";
}


?>

<?php
// scripte d'erreure
error_reporting(E_ALL);
ini_set('display_errors','1'); ?>

<?php 
//  question de admin pour suppremer contact
if(isset($_GET['deleteid'])){
echo 'est ce que sure de suppression le Contact N:'.$_GET['deleteid'].'?   <a href="contact_list_admin.php?yesdelete='.$_GET['deleteid'].'">OUI</a> | <a href="contact_list_admin.php">NON</a> ';
exit();
}

// la suppression de contact  a partire le system 
if(isset($_GET['yesdelete'])){
$id_to_delete=$_GET['yesdelete'];
$sql=mysql_query("DELETE FROM contact WHERE cont_id='$id_to_delete' LIMIT 1")or die(mysql_error) ;
header("location:contact_list_admin.php");
exit(); 
}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Gestion des Contact</title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />

<style type="text/css">
<!--
.Style1 {font-weight: bold}
-->
</style></head>
<body>
<div align="center" id="mainWrapper">

<?php  include_once("template_header2.php");?>
<div id="pageContent">
	<div id="rech_user_div" align="right">
		<form action="#" method="POST">
       		<a  href="#">Contact(<strong><?php echo $contCount1; ?></strong>)  </a>&nbsp;&nbsp;&nbsp;
            <a  href="indexAdmin.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 

<div align="left" style="margin-left:35px" ><br/>
  <p><strong>Bienvenue &nbsp;" &nbsp;<?php echo $username ?>&nbsp; "&nbsp;dans gestion des contacts :</strong>
  </p>
  <br/><br/>
</div>
<div style="margin-left: 24px" align="left">
  <h3><strong>Liste Des  Contacts non vue:</strong></h3>
  <?php echo  $tableAtt; ?>
  <?php echo $msg_list1; ?>
  <br/><br/><br/>
</div>
<hr color="#333333"/>
<div style="margin-left: 24px" align="left">
  <h3><strong>Liste Des  Contacts d&egrave;ja vue:</strong></h3>
  <?php
   echo  $tableAtt2;
   echo $msg_list2;
   ?>
  
  <br/><br/><br/>
</div>

</div></div>
<?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
