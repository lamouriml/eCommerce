<?php 
// importe le connexion de base de donnee
include"../storescripts/connect_to_mysql.php"; 
?>

<?php 
// laison avec le session de la logine admin
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}
//---------

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}

 ?>

<?php
// scripte d'erreure
 error_reporting(E_ALL);
ini_set('display_errors','1'); ?>
<?php 
		

// parse le formulaire Modif une article
if(isset($_POST['product_name'])){
$pid=mysql_real_escape_string($_POST['thisID']);
$idt=mysql_real_escape_string($_POST['id']);
$product_name=mysql_real_escape_string($_POST['product_name']);
$price=mysql_real_escape_string($_POST['price']);
		
		$sql_O_Price=mysql_query("select * from products where id='$pid' LIMIT 1");
		$rew_priceOld=mysql_fetch_array($sql_O_Price);
		if(isset($_POST['Modif_price'])){
		$priceOld=$rew_priceOld['price'];
		}else{
			$priceOld="";
			}
$category= mysql_real_escape_string($_POST['category']);
$subcategory= mysql_real_escape_string($_POST['subcategory']);
$details= mysql_real_escape_string($_POST['details']);
$case_art= mysql_real_escape_string($_POST['case']);

$time_now = date("H:i:s"); 
$sql0= mysql_query("update products set product_name='$product_name',price='$price',price2='$priceOld',category='$category',subcategory='$subcategory',product_case='$case_art',details='$details' where id='$pid' LIMIT 1");

if($_FILES['fileField']['tmp_name']!=""){
 $newname="$pid.jpg";
 move_uploaded_file($_FILES['fileField']['tmp_name'], "../inventory_images/$newname");

} 
 header("location:inventory_list.php");
 exit(); 
} 

///////////////////////////

		
?>

<?php 
//  assurer que le fourmulaire est plin de information
if(isset($_GET['pid'])){
    $targetID=$_GET['pid'];
	$sql=mysql_query("select * from products WHERE id='$targetID' LIMIT 1");
	$productCount=mysql_num_rows($sql);
	
	if($productCount>0){
   		while($row=mysql_fetch_array($sql)){
      		
	  		$category=$row["category"];
			$subcategory=$row["subcategory"];
	   		$price=$row["price"];
	  		$product_name=$row["product_name"];
	  		$details=$row["details"];
			$case=$row["product_case"];
			$date_added=strftime("%d %b %Y",strtotime($row["date_added"]));
	  	}
	}
	else{
		echo ' l article not exist ,merci !! ';
	    exit();
	}
}

// The New Price

?>
 
 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Modifier l'information de L'article &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $product_name?></title>
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
<link href="../favicon.ico" rel="shortcut icon" />
<script>
function showCat(str)
{
if (str=="")
  {
  document.getElementById("subcatHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==3 && xmlhttp.status==200)
    {
    document.getElementById("subcatHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","inventory_list.php?q="+str,true);
xmlhttp.send();
}
</script>

</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
    <div id="rech_user_div" align="right">
        <form action="#" method="POST">
        	<a  href="inventory_list.php">Liste  </a>&nbsp;&nbsp;&nbsp;
            <a  href="index.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="submit" value="Search"  id="search_btn"   />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div> 
    
    <div style="margin-left: 24px" align="left">
      <h4><strong>la modification de l'article correspondont : &nbsp;&nbsp;<?php echo $product_name?></strong></h4>
      
      
      </div>
    <a name="inventoryForm"  id="inventoryForm"></a >
	<h2 class="Style1">
	  Modifier L'Article    </h2>
	<form id="myform" name="myform" method="post" action="inventory_edit.php" enctype="multipart/form-data">
	<table width="992" border="0">
     <tr>
    <td><div align="right">Cas de L'article:</div></td>
    <td>&nbsp;
    <font color="#00CC00">Disponible</font><input name="case" type="radio" value="Disponible"/>&nbsp;&nbsp;&nbsp;
    <font color="#FF9933">Limmiter</font><input name="case" type="radio" value="Limmiter" />&nbsp;&nbsp;&nbsp;
    <font color="#FF0000">Indisponible</font><input name="case" type="radio" value="Indisponible" />
    
    </td>
  </tr>
    
  <tr>
    <td width="237"><div align="right">Nom:</div></td>
    <td width="739"><input name="product_name" type="text" class="iscritfield" id="product_name"  value="<?php echo $product_name?>" size="50"/></td>
  </tr>
  <tr>
    <td><div align="right">Prix:</div></td>
    <td> <input name="price" type="text" class="iscritfield" value="<?php echo $price?>" size="20"/> DA&nbsp;&nbsp;&nbsp;<input name="Modif_price" type="checkbox" value="Modif_price" />
    Afficher les Deux prix
    </td>
  </tr>
  <tr>
    <td><div align="right">Categorie:</div></td>
    <td><select name="category"  id="category"size="1" onchange="showCat(this.value)">
    <option value="<?php echo $category; ?>"><?php echo $category; ?></option>
  <?php 
		  $sql_cat=mysql_query("SELECT * from categorie" )or die(mysql_error) ;
		  while($res_cat = mysql_fetch_array($sql_cat)){
			  $cat_name=$res_cat['cat_name'];
			  $id_categorie=$res_cat['id_categorie'];
		  ?>
<option value="<?php echo  $id_categorie ?>"><?php echo $cat_name ?></option>
 <?php }?>
    </select>   </td>
  </tr>
  <tr>
    <td><div align="right">Sous Categorie:</div></td>
    <td>
    <select name="subcategory"   id="subcatHint" size="1">
	  <option value="<?php echo $subcategory ?>" selected="selected"><?php echo $subcategory ?></option>
	  <?php 
  			$q=$_GET["q"];
		  $sql_subcat=mysql_query("SELECT * from subcategorie where id_category='$q' " )or die(mysql_error) ;
		  while($res_subcat = mysql_fetch_array($sql_subcat)){
			  $subcat_name=$res_subcat['subcat_name'];
			  $id_subcategory=$res_subcat['id_subcategory'];
		  ?>
 <option  value="<?php echo $id_subcategory ?>"><?php echo $subcat_name ?></option>
<?php }?>
</select>
    </td>
  </tr>
  <tr>
    <td><div align="right">Detailes:</div></td>
    <td><textarea name="details" cols="70" rows="7" class="iscritfield"> <?php echo $details ?></textarea></td>
  </tr>
  <tr>
    <td><div align="right">Image:</div></td>
    <td><input name="fileField" type="file" size="50" /></td>
  </tr>
  <tr>
    <td><div align="right"></div></td>
    <td>
	  <br />
	    <input name="thisID" type="hidden" value="<?php echo $targetID ?>" />
	    <input type="submit" name="Submit" value="Appliquer Modif" />
	     
      </tr>
</table><br /><br />
    </form>
  <br /><br /><br /><br /><br />
  </div>
  <?php  include_once("template_footer2.php");?>
</div></div>
</body>
</html>
