<?php 
 error_reporting(E_ALL);
ini_set('display_errors','1');  ?>
<?php 
session_start();
if(!isset($_SESSION["session"])){
	header("location:admin_login.php");
	exit();
}

//////////////////////////////////////////////////
include"../storescripts/connect_to_mysql.php";
$session = $_SESSION["session"];
$sql=mysql_query("SELECT * FROM admin WHERE session='$session' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount==0){
echo 'le login est incorrect ';
exit();
}

$sql01=mysql_query("select * from admin where session='$session' ");
$userCount=mysql_num_rows($sql01);
if($userCount>0){
while($row=mysql_fetch_array($sql01)){
  $idadmin=$row["idadmin"];
  $username=$row["username"]; 
   $n=$row["nom"]; 
    $p=$row["prenom"]; 
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bienvenue &nbsp;" <?php echo $username ?> "&nbsp;dans gestion de votre compte</title>
<link href="../favicon.ico" rel="shortcut icon" />
<link href="../style/style.css" rel="stylesheet" type="text/css"  media="screen"/>
</head>
<body>
<div align="center" id="mainWrapper">
<?php  include_once("template_header2.php");?>
  <div id="pageContent">
  
      <div id="rech_user_div" align="right">
        <form action="#" method="POST">
        	<a  href="index.php">Gestion  </a>&nbsp;&nbsp;&nbsp;
            <a  href="../index.php?out">Deconnexion  </a>          
   		 <input name="Search" type="image" src="../images/simple_btn/Search.png"  />
         <input name="recherche" type="text" size="30"   value=""  id="search_txt" />  
     </form>
     </div>  
   
<div align="left">      
<div id="template_menu_header" ><font size="4" color="#FFFFFF "><strong>&nbsp;&nbsp;&nbsp;Votre Profile :</strong></font>	</div>        
<div id="templatemo_menu" >
       <ul>
       		<li> <a href="user_edit_login.php?uid=<?php echo $idadmin ?>"> Modif le Mot de pass</a> </li>
       		<li> <a href="user_edit_profil.php?uid=<?php echo $idadmin ?>">Modif Information</a> </li>
       		<li > <a href="inventory_list.php">Gestion de l'Article </a>  </li>
       </ul>       
  
  </div> </div>
<strong>Bienvenue &nbsp; <font color="#FF3300" size="+1"><?php echo $p.'&nbsp;'.$n ?></font> &nbsp;&nbsp;dans gestion de votre compte : </strong>
  
   <br /> <br /><br /><br /><br /><br /><br /><br />         
</div>   </div>   
  <?php  include_once("template_footer2.php");?>
</div>
</body>
</html>
